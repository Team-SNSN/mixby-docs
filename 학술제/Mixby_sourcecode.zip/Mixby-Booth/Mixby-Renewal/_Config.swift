//
//  Config.swift
//  Mixby-Booth
//
//  Created by Anthony on 9/24/25.
//

import SwiftUI

enum ServerURL {
    static let urlHeader: String = "http://snsn.kr:5050"
    
    static let persona: String = "\(urlHeader)/api/recommendations/persona"
    static let recommendDefault: String = "\(urlHeader)/api/recommendations/default"
    
    static let health: String = "\(urlHeader)/health"
    static let allRecipes: String = "\(urlHeader)/recipe/all"
    static let allIngredients: String = "\(urlHeader)/ingredient/all"
    
    static let d_img_header: String = "\(urlHeader)/drink/image="
    static let d_code_search: String = "\(urlHeader)/drink/code="
    
    static let r_img_header: String = "\(urlHeader)/recipe/image/code="
    static let r_code_search: String = "\(urlHeader)/recipe/code="
}
