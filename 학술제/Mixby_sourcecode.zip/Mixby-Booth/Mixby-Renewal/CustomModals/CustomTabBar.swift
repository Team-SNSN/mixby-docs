//
//  CustomTabBar.swift
//  Mixby-Booth
//
//  Created by Anthony on 9/19/25.
//

import SwiftUI

class TabItem {
    var icon: String
    var size: CGFloat
    
    init(icon: String, size: CGFloat) {
        self.icon = icon
        self.size = size
    }
}

struct CustomTabBar: View {
    @Binding var currentTab: Int
    @Binding var subTab: Int
    
    let tabs: [TabItem] = [
        TabItem(icon: "home", size: 32),
        TabItem(icon: "cocktail", size: 32),
        TabItem(icon: "shelf", size: 32),
        TabItem(icon: "note", size: 32)
    ]
    
    var body: some View {
        let horizontalPadding: CGFloat = 16
        
        ZStack(alignment: .topLeading) {
            
            HStack(spacing: 0) {
                ForEach(Array(tabs.enumerated()), id: \.offset) { index, tabItem in
                    Button(action: {
                        withAnimation(.easeInOut(duration: 0.2)) {
                            let oldTab = currentTab
                            currentTab = index
                            if currentTab == 1 {
                                OwnedRecipeManager.shared.fetchAvailableRecipes()
                            }
                            if currentTab == 2 && index == 2 && oldTab == 2 {
                                subTab = (subTab+1)%2
                            }
                        }
                    }) {
                        TabButton(currentTab: $currentTab, index: index, tabItem: tabItem)
                            .frame(maxWidth: .infinity)
                    }
                }
            }
        }
        .frame(height: 64)
        .glassEffect()
        .padding(.horizontal, horizontalPadding)
    }
}

struct TabButton: View {
    @Binding var currentTab: Int
    var index: Int
    var tabItem: TabItem
    
    var body: some View {
        ZStack {
            Image(tabItem.icon)
                .resizable()
                .frame(width: tabItem.size, height: tabItem.size)
                .padding(16)
        }
        .opacity(Double(1.5 - min(Double(abs(currentTab-index)), 1.0)))
    }
}
