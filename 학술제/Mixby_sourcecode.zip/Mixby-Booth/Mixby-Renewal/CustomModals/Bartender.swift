//
//  Bartender.swift
//  Mixby-Booth
//
//  Created by Anthony on 9/24/25.
//

import SwiftUI

struct BartenderProfile: View {
    var image_name: String = "snsn_profile"
    
    var body: some View {
        ZStack {
            Image(image_name)
                .resizable()
        }
        .backgroundExtensionEffect()
        .clipShape(Circle())
        .frame(width: 64, height: 64)
    }
}

