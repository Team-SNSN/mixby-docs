//
//  SwipeToDeleteModal.swift
//  Mixby-Booth
//
//  Created by Anthony on 10/2/25.
//

//
//  SwipeModal.swift
//  mechuri_test
//
//  Created by Anthony on 9/10/25.
//

import SwiftUI

struct SwipeToDeleteModal<Content: View>: View {
    @State private var showAlert: Bool = false
    @State private var dragX: CGFloat = 0
    @State private var cardDragStatus: Int = 0
    @State private var cardReveal: CGFloat = 0
    
    @State private var isDragging: Bool = false
    @State private var dragStartX: CGFloat = 0
    @State private var trashX: Bool = false
    
    private let revealPeek: CGFloat = 100
    private let revealMax: CGFloat = 300
    private let redBoxRatio: CGFloat = 0.6
    
    var rightMenu = "trash.fill"
    var rigthColor: Color = Color.mixby.pink.opacity(0.2)
    var alertTitle: String = "삭제"
    var alertText: String = "삭제하시겠습니까?"
    
    let content: () -> Content
    var onDelete: () -> Void = {}
    
    var body: some View {
        let revealCap: CGFloat = (cardDragStatus == 0 ? revealPeek : revealMax)
        let reveal: CGFloat = min(max(-dragX, 0), revealCap)
        
        ZStack(alignment: .trailing) {
            // Delete area sits behind, width matches reveal → no gap
            ZStack (alignment: trashX ? .leading : .center) {
                Rectangle()
                    .fill(rigthColor)
                    .cornerRadius(32)
                    .padding(8)
                
                Image(systemName: rightMenu)
                    .resizable()
                    .foregroundStyle(Color.white)
                    .frame(width: min(20, 20 * reveal/revealPeek), height: min(20, 20 * reveal/revealPeek))
                    .padding(.horizontal, 16)
            }
            .opacity(1 * reveal/revealPeek)
            .scaleEffect(min(1, reveal/revealPeek))
            .frame(
                width: max(0, reveal),
                height: revealPeek * redBoxRatio
            )
            .onTapGesture {
                if cardDragStatus == 1 {
                    withAnimation(.spring(response: 0.25, dampingFraction: 0.85)) {
                        dragX = 0
                    }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) {
                        isDragging = false
                        cardDragStatus = 0
                        cardReveal = 0
                        DispatchQueue.main.async {
                            withTransaction(Transaction(animation: .easeOut(duration: 0.1))) {
                                showAlert = true
                            }
                        }
                    }
                }
            }
            
            // Main card on top
            ZStack {
                content()
            }
            .offset(x: min(-reveal, 0))
        }
        .alert(alertTitle, isPresented: $showAlert) {
            Button("취소", role: .cancel) {
                // No action needed for cancel
            }
            Button("삭제", role: .destructive) {
                onDelete()
            }
        } message: {
            Text(alertText)
        }
        .padding(.horizontal, 16)
        .gesture(
            DragGesture(minimumDistance: 15, coordinateSpace: .local)
                .onChanged { value in
                    if abs(value.translation.width) > abs(value.translation.height) {
                        if !isDragging {
                            isDragging = true
                            dragStartX = dragX
                        }
                        let cap = (cardDragStatus == 0 ? revealPeek : revealMax * 1.6)
                        let proposed = dragStartX + value.translation.width
                        let allowedMin = -cap
                        let clamped = min(max(proposed, allowedMin), 0)
                        withAnimation(.interactiveSpring(response: 0.25, dampingFraction: 0.85)) {
                            dragX = clamped
                        }
                        withAnimation(.easeInOut(duration: 0.1)) {
                            trashX = -dragX > (revealMax + revealPeek) * 0.6 && cardDragStatus != 0
                        }
                    }
                }
                .onEnded { value in
                    isDragging = false
                    
                    let dragAbs = -dragX
                    let peekThreshold = revealPeek * 0.6
                    let deleteThreshold = (revealMax + revealPeek) * 0.6
                    
                    if dragAbs > deleteThreshold && cardDragStatus == 1 {
                        cardDragStatus = 0
                        cardReveal = 0
                        withAnimation(.spring(response: 0.3, dampingFraction: 0.85)) {
                            dragX = 0
                        }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) {
                            isDragging = false
                            cardDragStatus = 0
                            cardReveal = 0
                            DispatchQueue.main.async {
                                withTransaction(Transaction(animation: .easeOut(duration: 0.1))) {
                                    showAlert = true
                                }
                            }
                        }
                        return
                    } else if dragAbs >= peekThreshold && cardDragStatus == 0 {
                        cardDragStatus = 1
                        cardReveal = revealPeek
                        withAnimation(.spring(response: 0.3, dampingFraction: 0.85)) {
                            dragX = -revealPeek
                        }
                        return
                    } else {
                        cardDragStatus = 0
                        cardReveal = 0
                        withAnimation(.spring(response: 0.3, dampingFraction: 0.85)) {
                            dragX = 0
                        }
                        return
                    }
                }
        )
        .allowsHitTesting(!showAlert)
        .overlay(
            Group {
                if showAlert {
                    Color.black.opacity(0.001)
                        .ignoresSafeArea()
                }
            }
        )
    }
    
}
