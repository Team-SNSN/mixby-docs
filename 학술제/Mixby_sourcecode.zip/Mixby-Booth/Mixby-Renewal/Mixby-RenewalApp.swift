//
//  Mixby_BoothApp.swift
//  Mixby-Booth
//
//  Created by Anthony on 9/17/25.
//

import SwiftUI
import Combine

@main
struct Mixby_BoothApp: App {
    @StateObject private var appState = AppState()
    
    @State private var showSplash = true
    @State private var initializationStarted = false
    
    var body: some Scene {
        WindowGroup {
            ZStack {
                if showSplash {
                    SplashScreenView()
                        .onAppear {
                            startInitialization()
                        }
                } else {
                    NavigationStack {
                        ZStack {
                            AnimatedBackground().ignoresSafeArea()
                            ContentView()
                            overlayView
                        }
                    }
                    .background {
                        Color.mixby.black
                            .ignoresSafeArea()
                    }
                }
            }
        }
    }
    
    @ViewBuilder
    private var overlayView: some View {
        switch appState.serverStatus {
        case .loading, .unknown:
            LoadingOverlay()
        case .unhealthy:
            ErrorOverlay {
                retryServer()
            }
        default:
            EmptyView()
        }
    }
}

private struct LoadingOverlay: View {
    var body: some View {
        ZStack {
            Color.black.opacity(0.4).ignoresSafeArea()
            VStack(spacing: 16) {
                ProgressView()
                    .progressViewStyle(.circular)
                    .tint(.white)
                Text("서버 동기화 중…")
                    .font(.custom(Font.mixby, size: 18))
                    .foregroundStyle(.white)
            }
            .padding(24)
            .background(Color.black.opacity(0.6))
            .clipShape(RoundedRectangle(cornerRadius: 16))
        }
        .transition(.opacity)
    }
}

private struct ErrorOverlay: View {
    var retryAction: () -> Void
    
    var body: some View {
        ZStack {
            Color.black.opacity(0.4).ignoresSafeArea()
            VStack(spacing: 16) {
                Text("서버 동기화 실패")
                    .font(.custom(Font.mixby, size: 20))
                    .foregroundStyle(Color.mixby.pink)
                Text("네트워크 상태를 확인하고 다시 시도해주세요.")
                    .font(.custom(Font.mixby, size: 14))
                    .foregroundStyle(.white.opacity(0.7))
                
                Button(action: retryAction) {
                    Text("다시 시도")
                        .font(.custom(Font.mixby, size: 16))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 24)
                        .padding(.vertical, 12)
                        .background(Color.mixby.pink.opacity(0.8))
                        .clipShape(Capsule())
                }
            }
            .padding(24)
            .background(Color.black.opacity(0.6))
            .clipShape(RoundedRectangle(cornerRadius: 16))
        }
        .transition(.opacity)
    }
}

extension Mixby_BoothApp {
    @MainActor
    private func startInitialization() {
        guard !initializationStarted else { return }
        initializationStarted = true
        
        appState.retryServerCheck()
        
        LocationManager.shared.requestPermission()
        LocationManager.shared.requestSingleLocation { lat, lon in
            print("초기 위치 저장:", lat, lon)
        }
        
        Task {
            // STEP 1 — Persona 생성
            let settingManager = SettingsManager.shared
            let userData = PersonaLoader.UserData(
                name: settingManager.loadUsername(),
                gender: ["남성", "여성"][settingManager.loadOption1()],
                favoriteTaste: ["알코올 맛", "단 맛", "상큼한 맛"][settingManager.loadOption2()]
            )
            
            let tastingList = NoteLoader.shared.notedRecipes.map { $0.toTastingData() }
            
            // PersonaLoader (콜백 → await 변환)
            await withCheckedContinuation { continuation in
                PersonaLoader.shared.requestPersona(
                    user: userData,
                    tastings: tastingList
                ) { result in
                    if let persona = result?.persona {
                        print("📌 생성된 Persona: \(persona)")
                    } else {
                        print("❌ Persona 생성 실패")
                    }
                    continuation.resume()
                }
            }
            
            let timeManager = TimeManager.shared
            
            RecommendManager.shared.requestRecommendation(
                persona: PersonaLoader.shared.savedPersona,
                cocktails: OwnedRecipeManager.shared.ownedRecipesAll,
                season: timeManager.currentSeason().rawValue,
                time: timeManager.currentTimeCategory().rawValue,
                weather: "맑음"
            ) { response in
                if let response = response {
                    print("\n추천 성공")
                    print(response)
                } else {
                    print("\n추천 실패")
                }
            }
        }
        
        Task {
            async let minimumDelay = sleepMinimumDuration()
            async let statusUpdate = waitForServerStatus()
            _ = await minimumDelay
            _ = await statusUpdate
            await MainActor.run {
                withAnimation(.easeInOut(duration: 0.35)) {
                    showSplash = false
                }
            }
        }
    }
    
    private func sleepMinimumDuration() async {
        let duration: UInt64 = 2_000_000_000 // 2 seconds
        try? await Task.sleep(nanoseconds: duration)
    }
    
    private func waitForServerStatus() async {
        if appState.serverStatus != .loading && appState.serverStatus != .unknown {
            return
        }
        
        for await status in appState.$serverStatus.values {
            if status != .loading && status != .unknown {
                break
            }
        }
    }
    
    @MainActor
    private func retryServer() {
        initializationStarted = false
        showSplash = true
    }
}
