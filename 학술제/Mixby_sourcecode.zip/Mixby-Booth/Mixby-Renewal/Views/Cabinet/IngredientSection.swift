//
//  ToolSection.swift
//  Mixby-Booth
//
//  Created by Anthony on 10/2/25.
//

import SwiftUI

struct IngredientSection: View {
    let sectionLength: Int = 4
    let sectionTitles: [String] = ["리큐르", "베르무트", "비터스", "기타"]
    let sectionRanges: [Range<Int>] = [200..<300, 810..<900, 900..<1000, 0..<100]
    
    var body: some View {
        ScrollView {
            VStack {
                ForEach(0..<sectionLength) { index in
                    IngredientContent(title: sectionTitles[index], range: sectionRanges[index])
                    
                    if index < sectionLength-1 {
                        MixbyDivider()
                            .padding(.vertical, 8)
                    }
                }
                
                Spacer()
                
                Spacer().frame(height: Dummy.tabbarHeight)
            }
            .padding(8)
        }
    }
}

struct IngredientContent: View {
    @State private var isExpanded: Bool = true
    
    var title: String = ""
    var range = 0..<100
    
    var body: some View {
        
        ZStack {
            SectionTitle(text: title)
            HStack {
                Spacer()
                Image(systemName: isExpanded ? "chevron.up" : "chevron.down")
                    .foregroundColor(.white)
                    .padding(.trailing, 16)
                    .frame(width: 30)
                    .onTapGesture {
                        withAnimation(.spring()) {
                            isExpanded.toggle()
                        }
                    }
            }
        }
        .padding(.bottom, 8)
        
        if isExpanded {
            LazyVGrid(
                columns: Array(repeating: GridItem(.flexible(), spacing: 12, alignment: .top), count: 2)) {
                    ForEach(
                        IngredientDict.shared.ingredients.filter {
                            if let codeValue = Int($0.code) {
                                return (range).contains(codeValue)
                            }
                            return false
                        }, id: \.code
                    ) { ing in
                        IngredientCard(ingredient: ing)
                            
                    }
                }
        }
    }
}

struct IngredientCard: View {
    @ObservedObject var manager = OwnedIngredientsManager.shared
    @State var isChecked: Bool = false
    
    var ingredient: Ingredient
    
    var body: some View {
        HStack {
            Spacer()
            Text(ingredient.name)
                .font(.custom(Font.mixby, size: 14))
                .foregroundColor(Color.mixby.pink)
                .padding(.vertical, 16)
            Spacer()
        }
        .mixbyGlass(cornerRadius: 12)
        .opacity(isChecked ? 1 : 0.5)
        .onAppear{
            if manager.ownedIngredients.contains(ingredient.code) {
                isChecked = true
            } else {
                isChecked = false
            }
        }
        .onTapGesture {
            if isChecked {
                manager.removeIngredient(ingredient.code)
                isChecked = false
            } else {
                manager.addIngredient(ingredient.code)
                isChecked = true
            }
        }
    }
}
