//
//  DrinkSection.swift
//  Mixby-Booth
//
//  Created by Anthony on 10/2/25.
//

import SwiftUI

struct DrinkSection: View {
    
    @ObservedObject var manager = OwnedDrinksManager.shared
    
    var body: some View {
        Group {
            if manager.ownedDrinks.isEmpty {
                Text("술을 추가해 보세요")
                    .font(.custom(Font.mixby, size: 16))
                    .foregroundStyle(Color.mixby.pink)
                    .padding(.vertical, 32)
                
            } else {
                VStack(alignment: .center, spacing: 32) {
                    LazyVGrid(columns: [GridItem(.flexible())], spacing: 8) {
                        ForEach(manager.ownedDrinks, id: \.code) { drink in
                            DrinkSectionCard(code: drink.code) {
                                Task { @MainActor in
                                    manager.removeDrink(drink)
                                }
                            }
                        }
                    }
                    .padding(.top, 16)
                }
            }
        }
    }
}

struct DrinkSectionCard: View {

    let code: String
    var onDelete: () -> Void

    // view state
    @State private var isLoading: Bool = false
    @State private var drink: Drink? = nil
    @State private var loadError: String? = nil
    @State private var myCode: String = ""

    var body: some View {
        SwipeToDeleteModal(
            content: {
                ZStack {
                    if isLoading {
                        EmptyView()
                    } else if let drink = drink {
                        VStack {
                            HStack (spacing: 32) {
                                RemoteImageView(
                                    imageType: 0,
                                    code: drink.code,
                                    scaling: .fill,
                                    targetPixelDimension: 200
                                )
                                .clipShape(Circle())
                                .scaleEffect(1.5)
                                .frame(width: 80, height: 80)
                                .vignetteBlur()

                                VStack(alignment: .leading, spacing: 16) {

                                    Text(drink.name)
                                        .font(.custom(Font.mixby, size: 16))
                                        .foregroundColor(Color.mixby.pink)
                                        .multilineTextAlignment(.leading)

                                    HStack {
                                        Text(drink.type)
                                            .font(.custom(Font.mixby, size: 14))
                                            .foregroundColor(.white.opacity(0.9))
                                        Spacer()
                                        Text("도수: \(drink.alcohol)")
                                            .font(.custom(Font.mixby, size: 14))
                                            .foregroundColor(.white.opacity(0.8))
                                    }
                                }

                                Spacer()
                            }

                            Divider()
                                .background(Color.white.opacity(0.2))
                                .padding(.top, 4)
                                .padding(.bottom, 12)

                            Text(drink.description)
                                .font(.custom(Font.mixby, size: 14))
                                .foregroundColor(.white.opacity(0.9))
                                .lineSpacing(4)
                        }
                        .padding(16)
                        .background(Color.black.opacity(0.25))
                        .cornerRadius(12)

                    } else if let error = loadError {
                        VStack(spacing: 12) {
                            Text("오류")
                                .font(.custom(Font.mixby, size: 18))
                                .foregroundColor(.white)
                            Text(error)
                                .font(.custom(Font.mixby, size: 14))
                                .foregroundColor(.white.opacity(0.8))
                        }
                        .padding()
                        .background(Color.red.opacity(0.15))
                        .cornerRadius(12)
                    } else {
                        Text("정보 없음")
                            .foregroundColor(.white)
                    }
                }
            },
            onDelete: onDelete
        )
        .onAppear {
            myCode = code
            loadDrink(code: code)
        }
    }

    private var toolbarTitle: String {
        if isLoading { return "불러오는 중…" }
        if let d = drink { return d.name }
        return "음료 정보"
    }

    private func loadDrink(code: String) {
        // avoid duplicate loads
        guard !isLoading && drink == nil && loadError == nil else { return }

        isLoading = true
        loadError = nil

        DrinkLoader.shared.fetchDrink(code: code) { success, fetchedDrink in
            DispatchQueue.main.async {
                self.isLoading = false
                if success, let fetched = fetchedDrink {
                    self.drink = fetched
                } else {
                    self.loadError = "음료 정보를 불러오지 못했습니다."
                }
            }
        }
    }
}
