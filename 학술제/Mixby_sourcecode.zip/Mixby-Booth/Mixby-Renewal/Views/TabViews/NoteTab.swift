//
//  NotesTab.swift
//  Mixby-Booth
//
//  Created by Anthony on 9/19/25.
//

import SwiftUI

struct NoteTab: View {
    var body: some View {
        ScrollView {
            VStack {
                NoteSection()
                Spacer()
                Spacer().frame(height: Dummy.tabbarHeight)
            }
            .padding(.horizontal, 16)
        }
    }
}

struct NoteSection: View {
    
    @ObservedObject var manager = OwnedRecipeManager.shared
    @ObservedObject var noteLoader = NoteLoader.shared
    
    var body: some View {
        
        Text("작성을 완료했어요")
            .font(.custom(Font.mixby, size: 16))
            .foregroundStyle(Color.white)
            .padding(8)
            .background(Capsule().fill(Color.white.opacity(0.1)))
            .padding(.top, 8)
        
        let owned = Set(manager.ownedRecipesAll)
        let notedNames = Set(noteLoader.notedRecipes.map { $0.name })
        let completed = RecipeDict.shared.recipes.filter { owned.contains($0.english_name) && notedNames.contains($0.english_name) }
        let pending   = RecipeDict.shared.recipes.filter { owned.contains($0.english_name) && !notedNames.contains($0.english_name) }

        LazyVGrid(columns: [GridItem(.flexible())], spacing: 12) {
            ForEach(completed, id: \.code) { recipe in
                NavigationLink(destination: RecipeView(recipe: recipe, isEditing: false)) {
                    NoteContent(recipe: recipe)
                }
            }
        }
        .padding(.vertical, 8)
        
        MixbyDivider()
        
        Text("작성이 필요해요")
            .font(.custom(Font.mixby, size: 16))
            .foregroundStyle(Color.white)
            .padding(8)
            .background(Capsule().fill(Color.white.opacity(0.1)))
        
        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
            ForEach(pending, id: \.code) { recipe in
                NavigationLink(destination: RecipeView(recipe: recipe, isEditing: true)) {
                    RecipeCard(recipe: recipe)
                }
            }
        }
        .padding(.vertical, 8)
    }
}

struct NoteContent: View {
    @ObservedObject var loader = NoteLoader.shared
    
    var recipe: Recipe
    
    var body: some View {
        HStack (spacing: 16) {
            RemoteImageView(
                imageType: 1,
                code: recipe.code,
                scaling: .fill,
                targetPixelDimension: 200
            )
            .frame(width: 80, height: 80)
            .cornerRadius(16)
            .padding(16)
            
            VStack (alignment: .leading, spacing: 8) {
                HStack (alignment: .bottom, spacing: 16) {
                    Text(recipe.korean_name)
                        .font(.custom(Font.mixby, size: 14))
                        .foregroundStyle(Color.mixby.pink.opacity(0.9))
                    
                    HStack (spacing: 8) {
                        Text(recipe.tag1 ?? "")
                        Text(recipe.tag2 ?? "")
                    }
                    .font(.custom(Font.mixby, size: 12))
                    .foregroundStyle(Color.white.opacity(0.4))
                    
                    Spacer()
                }
                
                VStack (spacing: 8) {
                    let vals = loader.getValue(name: recipe.english_name)

                    HorizontalBar(text: "당도", value: Double(vals.val1))
                    HorizontalBar(text: "산미", value: Double(vals.val2))
                    HorizontalBar(text: "알코올", value: Double(vals.val3))
                }
            }
            .padding(.trailing, 16)
        }
        .mixbyGlass(cornerRadius: 32)
    }
}

struct HorizontalBar: View {
    var text: String = ""
    var value: Double = 0
    
    var body: some View {
        HStack (spacing: 12) {
            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    let ratio = CGFloat(Double(value - 1) / 6.0)
                    
                    Capsule()
                        .fill(
                            LinearGradient(
                                gradient: Gradient(colors: gradientColors(for: value)),
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .frame(width: geo.size.width * ratio)
                }
            }
            .frame(height: 8)
            .clipShape(Capsule())
            .overlay(
                Capsule()
                    .stroke(Color.white.opacity(0.2), lineWidth: 1)
            )
            
            Text(text)
                .font(.custom(Font.mixby, size: 12))
                .foregroundStyle(Color.white.opacity(0.5))
                .frame(width: 48, alignment: .leading)
        }
    }
    
private func gradientColors(for value: Double) -> [Color] {
    let distanceFromCenter = abs(value - 4)
    let intensity = 0.4 + 0.1 * distanceFromCenter

    switch value {
    case ..<4:
        return [Color.mixby.purple.opacity(0.2), Color.mixby.purple.opacity(intensity)]
    case 4:
        return [Color.green.opacity(0.2), Color.green.opacity(0.8)]
    default:
        return [Color.red.opacity(0.2), Color.red.opacity(intensity)]
    }
}
}
