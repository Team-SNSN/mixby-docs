//
//  RecipeTab.swift
//  Mixby-Renewal
//
//  Created by Anthony on 10/29/25.
//

import SwiftUI

struct RecipeTab: View {
    
    var body: some View {
        ScrollView {
            VStack (spacing: 0) {
                RecipeSection(type: 0)
                
                MixbyDivider()
                    .padding(.top, 16)
                
                RecipeSection(type: 1)
                
                Spacer()
                
                Spacer()
                    .frame(height: Dummy.tabbarHeight)
            }
            .padding(.horizontal, 16)
        }
    }
}

struct RecipeSection: View {
    @ObservedObject var manager = OwnedRecipeManager.shared
    
    let type: Int
    
    private let sectionTitles = ["보유 중인 레시피", "해금 중인 레시피"]
    private let sectionMents = ["제작 가능한 레시피가 없어요", "재료를 추가해 레시피를 해금해보세요"]
    
    private var recipeSet: [String] {
        switch type {
        case 0: return manager.ownedRecipesAll
        case 1: return manager.ownedRecipesSome
        default: return []
        }
    }
    
    var body: some View {
        VStack(alignment: .center, spacing: 8) {
            Text(sectionTitles[type])
                .font(.custom(Font.mixby, size: 16))
                .foregroundStyle(Color.white)
                .padding(8)
                .background(Capsule().fill(Color.white.opacity(0.1)))
                .padding(.top, 8)
            
            if manager.isSectionEmpty(section: type) {
                Text(sectionMents[type])
                    .font(.custom(Font.mixby, size: 14))
                    .foregroundStyle(Color.mixby.pink)
                    .padding(.vertical, 16)
            }
            
            LazyVGrid(
                columns: Array(repeating: GridItem(.flexible(), spacing: 12, alignment: .top), count: 2),
                spacing: 12
            ) {
                ForEach(
                    RecipeDict.shared.recipes
                        .filter { recipeSet.contains($0.english_name) }
                        .sorted {
                            let lhs = OwnedRecipeManager.shared.getIngredientRatio(recipe: $0)
                            let rhs = OwnedRecipeManager.shared.getIngredientRatio(recipe: $1)
                            // 내림차순 정렬 → 보유 비율이 높은 레시피가 위로
                            return (lhs.0 / lhs.1) > (rhs.0 / rhs.1)
                        },
                    id: \.english_name
                ) { recipe in
                    if type == 0 {
                        NavigationLink(destination: RecipeView(recipe: recipe)) {
                            RecipeCard(recipe: recipe, type: type)
                        }
                    } else {
                        RecipeCard(
                            recipe: recipe,
                            type: type,
                            ratio: OwnedRecipeManager.shared.getIngredientRatio(recipe: recipe)
                        )
                    }
                }
            }
            .padding(.vertical, 8)
        }
    }
}


struct RecipeCard: View {
    @State private var showDetail: Bool = false
    @State private var isLoading: Bool = false
    
    var recipe: Recipe? = nil
    var type: Int = 0
    
    private let textOpacity: [Double] = [1.0, 0.8]
    var ratio: (Float, Float) = (1.0, 1.0)
    
    var body: some View {
        if let recipe = recipe {
            if isLoading {
                EmptyView()
            } else {
                ZStack {
                    ZStack {
                        LazyVGrid(
                            columns: [
                                GridItem(.flexible(), alignment: .center),
                                GridItem(.flexible(), alignment: .center)
                            ],
                            alignment: .center,
                            spacing: 6
                        ) {
                            let ownedIngredients = OwnedIngredientsManager.shared.ownedIngredients
                            ForEach(recipe.ingredients, id: \.name) { ingredient in
                                let isOwned = ownedIngredients.contains(ingredient.code)
                                Text(ingredient.name)
                                    .font(.custom(Font.mixby, size: 10))
                                    .foregroundColor(.white.opacity(isOwned ? 1.0 : 0.4))
                                    .multilineTextAlignment(.center)
                                    .frame(maxWidth: .infinity)
                            }
                        }
                        .frame(maxWidth: .infinity, alignment: .center)
                        .padding(.trailing, 10)
                        
                    }
                    .opacity(showDetail ? 1.0 : 0.0)
                    
                    ZStack {
                        HStack(alignment: .center) {
                            ZStack {
                                let (ownedCnt, totalCnt) = ratio
                                
                                Circle().fill(Color.black)
                                
                                RemoteImageView(
                                    imageType: 1,
                                    code: recipe.code,
                                    scaling: .fill,
                                    targetPixelDimension: 200
                                )
                                .clipShape(Circle())
                                .opacity(ownedCnt == totalCnt ? 1.0 : CGFloat(ownedCnt)/(CGFloat(totalCnt+2)))
                                
                                if type != 0 {
                                    HStack {
                                        Text("\(Int(ownedCnt)) / \(Int(totalCnt))")
                                            .font(.custom(Font.mixby, size: 16))
                                            .foregroundStyle(Color.white.opacity(1.0))
                                    }
                                }
                            }
                            .frame(width: 56, height: 56)
                            .padding(.leading, 8)
                            .padding(.vertical, 8)
                            
                            Spacer()
                            
                            
                            VStack(spacing: 16) {
                                Text(recipe.korean_name)
                                    .font(.custom(Font.mixby, size: 14))
                                    .foregroundColor(Color.mixby.pink.opacity(textOpacity[type]))
                                
                                HStack {
                                    Text("#\(recipe.tag1 ?? "")")
                                        .font(.custom(Font.mixby, size: 9))
                                        .foregroundColor(Color.white.opacity(textOpacity[type]))
                                    
                                    Text("#\(recipe.tag2 ?? "")")
                                        .font(.custom(Font.mixby, size: 9))
                                        .foregroundColor(Color.white.opacity(textOpacity[type]))
                                }
                            }
                            .padding(.trailing, 10)
                            
                            Spacer()
                        }
                    }
                    .opacity(showDetail ? 0.0 : 1.0)
                }
                .mixbyGlass(cornerRadius: 100)
                .onTapGesture {
                    if type == 1 {
                        withAnimation(.easeInOut(duration: 0.25)) {
                            showDetail.toggle()
                        }
                    }
                }
                .allowsHitTesting(type == 1)
                .id(recipe.english_name)
            }
        }
    }
}
