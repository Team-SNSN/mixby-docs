//
//  CabinetTab.swift
//  Mixby-Booth
//
//  Created by Anthony on 9/24/25.
//

import SwiftUI

struct CabinetTab: View {
    @Binding var subTab: Int
//    @Binding var gotoBarcodeView: Bool
    
    var body: some View {
        ZStack {
            switch subTab {
            case 0:
                ScrollView {
                    VStack {
                        DrinkSection()
                        Spacer()
                    }
                }
            case 1:
                ScrollView {
                    VStack {
                        IngredientSection()
                        Spacer()
                    }
                }
            default:
                EmptyView()
            }
        }
        .animation(.easeInOut(duration: 0.1), value: subTab)
    }
}
