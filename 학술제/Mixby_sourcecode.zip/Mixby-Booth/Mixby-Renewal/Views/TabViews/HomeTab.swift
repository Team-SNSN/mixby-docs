//
//  HomeTab.swift
//  Mixby-Booth
//
//  Created by Anthony on 9/19/25.
//

import SwiftUI

enum Size {
    case small
    case big
}

private struct RecommendSectionHeader: View {
    let title: String
    
    var body: some View {
        Text(title)
            .font(.custom(Font.mixby, size: 16))
            .foregroundStyle(Color.white)
            .padding(8)
            .background(Capsule().fill(Color.white.opacity(0.1)))
            .padding(.horizontal, 16)
    }
}

struct HomeTab: View {
    
    @StateObject var recommendManager = RecommendManager.shared
    
    var body: some View {
        //        Text("Count: \(recommendManager.savedRecommendations.count)").foregroundColor(.white)
        
        ScrollView {
            VStack {
                RecipeRecommendSection(recommendManager: recommendManager, title: "오늘의 추천", size: .big)
                NoteRecommendSection(title: "랜덤 레시피", size: .small)
                Spacer()
            }
            Spacer().frame(height: Dummy.tabbarHeight)
        }
    }
}

struct RecipeRecommendSection: View {
    
    @ObservedObject var recommendManager: RecommendManager
    
    var title: String = "추천 레시피"
    var size: Size = .small
    
    var body: some View {
        VStack (alignment: .leading, spacing: 8) {
            HStack(alignment: .center) {
                RecommendSectionHeader(title: title)
                Spacer()
            }
            
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 0) {
                    ForEach(Array(displayItems.enumerated()), id: \.offset) { _, item in
                        RecipeRecommendCard(recommend: item, size: size)
                            .transition(
                                .asymmetric(
                                    insertion: .scale.combined(with: .opacity),
                                    removal: .opacity
                                )
                            )
                    }
                }
                .animation(.spring(response: 0.45, dampingFraction: 0.85), value: recommendManager.savedRecommendations)
            }
        }
        .padding(.top, 8)
        .padding(.bottom, 32)
    }
}

private extension RecipeRecommendSection {
    var displayItems: [RecommendItem] {
        let current = recommendManager.savedRecommendations
        if current.isEmpty {
            return Array(repeating: RecommendItem(name: "loading", tag: "", reason: "추천을 준비하고 있어요", recipe: nil), count: 3)
        }
        return current
    }
}

struct NoteRecommendSection: View {
    
    @ObservedObject var manager = OwnedRecipeManager.shared
    @ObservedObject var noteLoader = NoteLoader.shared
    
    var title: String = "추천 레시피"
    var size: Size = .small
    
    var body: some View {
        VStack (alignment: .leading, spacing: 8) {
            RecommendSectionHeader(title: title)
            
            ScrollView(.horizontal, showsIndicators: false) {
                LazyHStack(spacing: 0) {
                    ForEach(pendingRecommendations.shuffled().prefix(5), id: \.name) { item in
                        RecipeRecommendCard(recommend: item, size: size)
                    }
                }
            }
        }
        .padding(.top, 8)
        .padding(.bottom, 32)
    }
    
    private var pendingRecommendations: [RecommendItem] {
        let owned = Set(manager.ownedRecipesAll)
        let notedNames = Set(noteLoader.notedRecipes.map { $0.name })
        
        let pending = RecipeDict.shared.recipes.filter {
            owned.contains($0.english_name) && !notedNames.contains($0.english_name)
        }
        
        return pending.map {
            RecommendItem(
                name: $0.english_name,
                tag: "",
                reason: "아직 평가하지 않은 레시피입니다.",
                recipe: $0
            )
        }
    }
}


struct RecipeRecommendCard: View {
    
    var recommend: RecommendItem
    
    var size: Size = .small
    var widthBig: CGFloat = DeviceManager.shared.screenWidth * 0.65
    var widthSmall: CGFloat = DeviceManager.shared.screenWidth * 0.35
    
    var body: some View {
        content
            .cornerRadius(20)
            .frame(width: cardWidth, height: cardHeight)
            .padding(.horizontal, 8)
    }
    
    @ViewBuilder
    private var content: some View {
        if let recipe = recommend.recipe {
            NavigationLink(destination: RecipeView(recipe: recipe, isEditing: size == .small)) {
                VStack(spacing: 0) {
                    topSection(for: recipe)
                    bottomSection(for: recipe)
                }
            }
        } else {
            placeholder
        }
    }
    
    private var cardWidth: CGFloat {
        size == .big ? widthBig : widthSmall
    }
    
    private var cardHeight: CGFloat {
        cardWidth * 1.4
    }
    
    private var infoHeight: CGFloat {
        cardWidth * 0.4
    }
    
    @ViewBuilder
    private func topSection(for recipe: Recipe) -> some View {
        ZStack {
            Rectangle().fill(Color.black.opacity(0.5))
            recipeImage(for: recipe)
            
            if size == .big {
                VStack {
                    HStack {
                        Text(recommend.tag)
                            .font(.custom(Font.mixby, size: 16))
                            .foregroundStyle(Color.white)
                            .padding(8)
                            .background{
                                Rectangle()
                                    .fill(Color.black.opacity(0.6))
                                    .cornerRadius(20)
                            }
                        Spacer()
                    }
                    .padding(8)
                    
                    Spacer()
                    Text(recommend.reason)
                        .font(.custom(Font.mixby, size: 14))
                        .foregroundStyle(Color.black)
                        .multilineTextAlignment(.center)
                        .padding(8)
                        .background{
                            Rectangle()
                                .fill(Color.white.opacity(0.8))
                                .cornerRadius(10)
                        }
                        .padding(8)
                }
            }
        }
        .frame(height: cardWidth)
    }
    
    @ViewBuilder
    private func bottomSection(for recipe: Recipe) -> some View {
        ZStack {
            blurredRecipeBackground(for: recipe)
            Rectangle().fill(Color.black.opacity(0.3))
            
            VStack(spacing: 16) {
                Text(recipe.korean_name)
                    .font(.custom(Font.mixby, size: size == .small ? 14 : 20))
                    .foregroundColor(Color.mixby.pink)
                
                HStack {
                    tagLabel(recipe.tag1)
                    tagLabel(recipe.tag2)
                }
            }
        }
        .frame(height: infoHeight)
    }
    
    @ViewBuilder
    private func tagLabel(_ tag: String?) -> some View {
        if let tag, !tag.isEmpty {
            Text("#\(tag)")
                .font(.custom(Font.mixby, size: size == .small ? 9 : 14))
                .foregroundColor(Color.white)
        }
    }
    
    private func recipeImage(for recipe: Recipe) -> some View {
        RemoteImageView(
            imageType: 1,
            code: recipe.code,
            scaling: .fill,
            targetPixelDimension: 200
        )
    }
    
    private func blurredRecipeBackground(for recipe: Recipe) -> some View {
        recipeImage(for: recipe)
            .blur(radius: 5)
            .scaleEffect(3.0)
            .frame(height: infoHeight)
            .clipped()
    }
    
    private var placeholder: some View {
        VStack {
            Spacer()
            
            TransparentGIFView(gifName: "loading")
                .frame(width: 60, height: 60)

            Spacer()
        }
        .frame(width: cardWidth, height: cardHeight)
        .background(Color.black.opacity(0.5))
    }
}
