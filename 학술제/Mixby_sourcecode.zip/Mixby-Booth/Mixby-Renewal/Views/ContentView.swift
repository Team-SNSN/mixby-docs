//
//  ContentView.swift
//  Mixby-Booth
//
//  Created by Anthony on 9/17/25.
//


import SwiftUI

enum Dummy {
    static let titleHeight: CGFloat = 48
    static let tabbarHeight: CGFloat = 80
}

struct ContentView: View {
    @State private var currentTab: Int = 0
    @State private var subTab: Int = 0
    
    @State private var gotoProfile: Bool = false
    @State private var gotoBarcodeView: Bool = false
    @State private var gotoCreditView: Bool = false
    
    let tabTitles: [String] = ["Mixby", "Recipes", "My", "Tasting Notes"]
    let subtabTitles: [String] = ["Drinks", "Ingredients"]
    let subButtonImage: [String] = ["arrow.counterclockwise", "person.fill", "plus", "gearshape.fill"]
    
    var body: some View {
        ZStack {
            VStack (spacing: 0) {
                HStack (alignment: .center) {
                    if (currentTab == 2) {
                        VStack (spacing: 2) {
                            ForEach(0..<subtabTitles.count, id: \.self) { index in
                                Circle()
                                    .fill(Color.white.opacity(subTab == index ? 0.7 : 0.2))
                                    .frame(width: 4, height: 4)
                            }
                        }
                    }
                    
                    Text("\(tabTitles[currentTab]) \(currentTab == 2 ? subtabTitles[subTab] : "")")
                        .font(.custom(Font.mixby, size: 16))
                        .foregroundColor(.white.opacity(0.8))
                        .padding(12)
                        .frame(height: 48)
                        .glassEffect()
                        .onTapGesture {
                            if currentTab == 2 {
                                withAnimation(.easeInOut(duration: 0.2)) { subTab = (subTab+1) % subtabTitles.count }
                            }
                        }
                    
                    Spacer()
                    
                    Button {
                        if (currentTab == 0) {
                            print("refresh recommend")
                            Task {
                                refreshRecommendations()
                            }
                        }
                        if (currentTab == 1) { withAnimation{ gotoProfile = true }}
                        if (currentTab == 2) {
                            withAnimation{ gotoBarcodeView = true }
                            subTab = 0
                        }
                        if (currentTab == 3) { withAnimation{ gotoCreditView = true }}
                    } label: {
                        Image(systemName: subButtonImage[currentTab])
                            .font(.system(size: 14))
                            .foregroundColor(.white.opacity(0.8))
                            .frame(width: 48, height: 48)
                            .glassEffect()
                    }
                }
                .padding(.bottom, 8)
                .padding(.horizontal, 16)
                
                Rectangle()
                    .frame(height: 1)
                    .foregroundColor(.white.opacity(0.1))
                
                switch currentTab {
                case 0:
                    HomeTab()
                case 1:
                    RecipeTab()
                case 2:
                    CabinetTab(subTab: $subTab)
                case 3:
                    NoteTab()
                default:
                    EmptyView()
                }
            }
            .navigationDestination(isPresented: $gotoProfile) { ProfileView(isPresented: $gotoProfile) }
            .navigationDestination(isPresented: $gotoBarcodeView) { BarcodeScannerView(isPresented: $gotoBarcodeView) }
            .navigationDestination(isPresented: $gotoCreditView) { CreditView(isPresented: $gotoCreditView) }
            
            VStack {
                Spacer()
                Rectangle()
                    .fill(LinearGradient(colors: [Color.mixby.purple.opacity(0), Color.black.opacity(0.6), Color.black.opacity(1)],
                                         startPoint: .top, endPoint: .bottom))
                    .frame(height: Dummy.tabbarHeight * 1.2)
                    .allowsHitTesting(false)
            }
            .ignoresSafeArea(.all)
        }
        .tint(Color.white)
        .overlay(alignment: .bottom) {
            CustomTabBar(currentTab: $currentTab, subTab: $subTab)
                .frame(height: Dummy.tabbarHeight)
        }
    }
}

private extension ContentView {
    func refreshRecommendations() {
        RecommendManager.shared.resetRecommendations()
        let timeManager = TimeManager.shared
        let persona = PersonaLoader.shared.savedPersona
        let cocktails = OwnedRecipeManager.shared.ownedRecipesAll
        RecommendManager.shared.requestRecommendation(
            persona: persona,
            cocktails: cocktails,
            season: timeManager.currentSeason().rawValue,
            time: timeManager.currentTimeCategory().rawValue,
            weather: "맑음"
        ) { response in
            if response == nil {
                print("추천 새로고침 실패")
            }
        }
    }
}
