//
//  RecipeView.swift
//  Mixby-Renewal
//
//  Created by Anthony on 10/29/25.
//

import SwiftUI

struct RecipeView: View {
    @State private var showAlert: Bool = false
    @State private var isEditing: Bool = false
    var recipe: Recipe?

    init(recipe: Recipe? = nil, isEditing: Bool = false) {
        self.recipe = recipe
        _isEditing = State(initialValue: isEditing)
    }
    
    var body: some View {
        if let recipe = recipe {
            ZStack {
                AnimatedBackground()
                
                VStack {
                    RecipeTopContent(recipe: recipe)
                    MixbyDivider()
                    
                    if !isEditing {
                        RecipeBottomContent(recipe: recipe)
                    } else {
                        NoteEditView(showAlert: $showAlert, isEditing: $isEditing, recipe: recipe)
                    }
                }
            }
            .toolbar {
                ToolbarItem(placement: .principal) {
                    Text("레시피")
                        .font(.custom(Font.mixby, size: 16))
                        .foregroundColor(.white)
                }
            }
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        withAnimation { isEditing.toggle() }
                    } label: {
                        Image(systemName: isEditing ? "checkmark" : "pencil")
                    }
                }
            }
            .overlay {
                if showAlert {
                    VStack {
                        Spacer()
                        Text("저장 완료!")
                            .font(.custom(Font.mixby, size: 24))
                            .foregroundStyle(Color.white)
                            .padding(8)
                            .mixbyGlass(cornerRadius: 100)
                            .onAppear {
                                DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                                    withAnimation {
                                        showAlert = false
                                    }
                                }
                            }
                        Spacer()
                        Spacer().frame(height: Dummy.tabbarHeight)
                    }
                }
            }
        }
        else {
            AnimatedBackground()
        }
    }
}

struct RecipeBottomContent: View {
    var recipe: Recipe
    
    let isPad = DeviceManager.shared.isPad
    var imageSize: CGFloat = DeviceManager.shared.screenWidth * 0.2
    
    var body: some View {
        
        if !isPad {
            Text("재료")
                .font(.custom(Font.mixby, size: 16))
                .foregroundColor(Color.white.opacity(0.6))
                .padding(.vertical, 16)
            
            VStack (alignment: .leading, spacing: 8) {
                ForEach(Array(recipe.ingredients.enumerated()), id: \.offset) { index, ingredient in
                    HStack {
                        
                        Circle()
                            .fill(Color.white.opacity(0.2))
                            .frame(width: imageSize * 0.2, height: imageSize * 0.2)
                        
                        Spacer().frame(maxWidth: imageSize * 0.8)
                        
                        Text(ingredient.name)
                            .font(.custom(Font.mixby, size: 16))
                            .foregroundColor(Color.mixby.pink)
                            .multilineTextAlignment(.leading)
                            .lineSpacing(4)
                        
                        Spacer()
                        
                        HStack {
                            if let amount = ingredient.amount {
                                Text(amount)
                                    .font(.custom(Font.mixby, size: 16))
                                    .foregroundColor(Color.white)
                                    .multilineTextAlignment(.leading)
                                    .lineSpacing(4)
                            }
                            
                            if let unit = ingredient.unit {
                                if unit != "" {
                                    Text(unit)
                                        .font(.custom(Font.mixby, size: 16))
                                        .foregroundColor(Color.white.opacity(0.8))
                                        .multilineTextAlignment(.leading)
                                        .lineSpacing(4)
                                }
                            }
                        }
                        .padding(8)
                        .mixbyGlass(cornerRadius: 100)
                    }
                }
            }
            .padding(.horizontal, 32)
            
            MixbyDivider()
        }
        
        Text("제조법")
            .font(.custom(Font.mixby, size: 16))
            .foregroundColor(Color.white.opacity(0.6))
            .padding(.vertical, 16)
        
        VStack (alignment: .leading, spacing: 16) {
            ForEach(recipe.instructions, id: \.self) { line in
                HStack {
                    Text(line)
                        .font(.custom(Font.mixby, size: 16))
                        .foregroundColor(Color.white)
                        .multilineTextAlignment(.leading)
                        .lineSpacing(4)
                    
                    Spacer()
                }
            }
        }
        .padding(.horizontal, 32)
        
        Spacer()
        Spacer().frame(height: Dummy.tabbarHeight)
    }
}

struct RecipeTopContent: View {
    var recipe: Recipe
    
    let isPad = DeviceManager.shared.isPad
    var imageSize: CGFloat = DeviceManager.shared.screenWidth * 0.2
    
    var body: some View {
        if isPad {
            VStack {
                HStack {
                    RemoteImageView(
                        imageType: 1,
                        code: recipe.code,
                        scaling: .fill,
                        targetPixelDimension: imageSize * 2
                    )
                    .cornerRadius(32)
                    .frame(width: imageSize, height: imageSize)
                    
                    Spacer()
                    
                    VStack (alignment: .center, spacing: 16) {
                        HStack (spacing: 32) {
                            Text(recipe.korean_name)
                                .font(.custom(Font.mixby, size: 16))
                                .foregroundColor(Color.mixby.pink)
                            
                            Text(recipe.english_name)
                                .font(.custom(Font.mixby, size: 16))
                                .foregroundColor(Color.white)
                        }
                        Text("#\(recipe.tag1 ?? "")  #\(recipe.tag2 ?? "")")
                            .font(.custom(Font.mixby, size: 14))
                            .foregroundColor(Color.white.opacity(0.7))
                    }
                    
                    Spacer()
                    
                    Rectangle()
                        .frame(width: 1, height: imageSize)
                        .foregroundStyle(Color.white.opacity(0.1))
                    
                    Spacer()
                    
                    VStack {
                        Text("재료")
                            .font(.custom(Font.mixby, size: 16))
                            .foregroundColor(Color.white.opacity(0.6))
                            .padding(.vertical, 16)
                        
                        VStack (alignment: .leading, spacing: 8) {
                            ForEach(Array(recipe.ingredients.enumerated()), id: \.offset) { index, ingredient in
                                HStack {
                                    
                                    Circle()
                                        .fill(Color.white.opacity(0.2))
                                        .frame(width: imageSize * 0.2, height: imageSize * 0.2)
                                    
                                    Spacer()
                                    
                                    Text(ingredient.name)
                                        .font(.custom(Font.mixby, size: 16))
                                        .foregroundColor(Color.mixby.pink)
                                        .multilineTextAlignment(.leading)
                                        .lineSpacing(4)
                                    
                                    Spacer()
                                    
                                    HStack {
                                        if let amount = ingredient.amount {
                                            Text(amount)
                                                .font(.custom(Font.mixby, size: 16))
                                                .foregroundColor(Color.white)
                                                .multilineTextAlignment(.leading)
                                                .lineSpacing(4)
                                        }
                                        
                                        if let unit = ingredient.unit {
                                            Text(unit)
                                                .font(.custom(Font.mixby, size: 16))
                                                .foregroundColor(Color.white.opacity(0.8))
                                                .multilineTextAlignment(.leading)
                                                .lineSpacing(4)
                                        }
                                    }
                                    .padding(8)
                                    .mixbyGlass(cornerRadius: 100)
                                }
                            }
                        }
                    }
                    .frame(maxWidth: DeviceManager.shared.screenWidth * 0.4)
                    
                    Spacer()
                }
                .padding(.vertical, 16)
                .padding(.horizontal, 32)
            }
        } else {
            VStack {
                HStack {
                    RemoteImageView(
                        imageType: 1,
                        code: recipe.code,
                        scaling: .fill,
                        targetPixelDimension: imageSize * 2
                    )
                    .cornerRadius(32)
                    .frame(width: imageSize, height: imageSize)
                    
                    Spacer()
                    
                    VStack (alignment: .center, spacing: 16) {
                        HStack (spacing: 32) {
                            Text(recipe.korean_name)
                                .font(.custom(Font.mixby, size: 16))
                                .foregroundColor(Color.mixby.pink)
                            
                            Text(recipe.english_name)
                                .font(.custom(Font.mixby, size: 16))
                                .foregroundColor(Color.white)
                        }
                        Text("#\(recipe.tag1 ?? "")  #\(recipe.tag2 ?? "")")
                            .font(.custom(Font.mixby, size: 14))
                            .foregroundColor(Color.white.opacity(0.7))
                    }
                    
                    Spacer()
                }
                .padding(.vertical, 16)
                .padding(.horizontal, 32)
            }
        }
    }
}
