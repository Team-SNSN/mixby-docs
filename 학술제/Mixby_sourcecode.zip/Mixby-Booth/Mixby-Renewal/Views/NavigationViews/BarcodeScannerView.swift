import SwiftUI
import AVFoundation

struct BarcodeScannerView: View {
    
    @Binding var isPresented: Bool
    
    @State private var scannedCode: String = ""
    @State private var addedCodes: [String] = []
    @State private var failedCodes: [String] = []
    @State private var scannedDrinks: [Drink] = []
    @State private var lastScanDate: Date = .distantPast
    
    @State private var showError: Bool = false
    @State private var overlayText: String = ""
    
    var body: some View {
        ZStack {
            AnimatedBackground()
            
            VStack (spacing: 0) {
                MixbyDivider()
                    .padding(.horizontal, -16)
                    .offset(y: 2)
                
                Text("주류의 바코드를 인식해주세요!")
                    .font(.custom(Font.mixby, size: 16))
                    .foregroundStyle(Color.mixby.pink)
                    .padding(8)
                    .mixbyGlass(cornerRadius: 20)
                    .padding(.vertical, 16)
                
                BarcodeScannerRepresentable { isFind, code in
                    print(isFind, code)
                    if isFind {
                        let now = Date()
                        guard now.timeIntervalSince(lastScanDate) >= 2 else { return }
                        lastScanDate = now
                        
                        if addedCodes.contains(code) || failedCodes.contains(code) {
                            if !showError {
//                                overlayText = "이미 인식한 상품이에요"
//                                showError = true
                            }
                        } else {
                            DrinkLoader.shared.fetchDrink(code: code) { isSuccess, optionalDrink in
                                if isSuccess, let drink = optionalDrink {
                                    scannedDrinks.append(drink)
                                    addedCodes.append(code)
                                } else {
                                    failedCodes.append(code)
                                    if !showError {
                                        overlayText = "해당 상품을 찾을 수 없어요"
                                        showError = true
                                    }
                                }
                            }
                        }
                    } else { showError = false }
                }
                .cornerRadius(16)
                .frame(height: 200)
                .padding(.horizontal, 16)
                .overlay {
                    if showError {
                        Text(overlayText)
                            .font(.custom(Font.mixby, size: 16))
                            .foregroundStyle(Color.red.opacity(0.8))
                            .padding(16)
                            .background(Capsule().foregroundStyle(.white.opacity(0.8)))
                    }
                }
                
                MixbyDivider()
                
                Text("인식된 상품")
                    .font(.custom(Font.mixby, size: 16))
                    .foregroundStyle(Color.mixby.pink)
                    .padding(8)
                    .padding(.vertical, 16)
                
                ScrollView {
                    VStack (spacing: 16) {
                        ForEach(Array(scannedDrinks.enumerated()), id: \.offset) { index, drink in
                            HStack {
                                RemoteImageView(
                                    imageType: 0,
                                    code: drink.code,
                                    scaling: .fill,
                                    targetPixelDimension: 200
                                )
                                .clipShape(Circle())
                                .scaleEffect(1.5)
                                .frame(width: 40, height: 40)
                                .vignetteBlur()
                                .padding(16)
                                
                                Text(drink.name)
                                    .font(.custom(Font.mixby, size: 16))
                                    .foregroundStyle(.white)
                            }
                        }
                    }
                    .padding(16)
                }
            }
        }
        .onAppear {
            addedCodes.removeAll()
            failedCodes.removeAll()
            scannedDrinks.removeAll()
            lastScanDate = .distantPast
        }
        .navigationBarItems(trailing: Button {
            for drink in scannedDrinks {
                    OwnedDrinksManager.shared.addDrink(drink)
                }
            withAnimation { isPresented = false }
        } label: {
            Text("저장")
                .font(.custom(Font.mixby, size: 14))
                .foregroundStyle(Color.white)
        })
        .toolbar {
            ToolbarItem(placement: .principal) {
                Text("주류 추가")
                    .font(.custom(Font.mixby, size: 16))
                    .foregroundColor(.white)
            }
        }
    }
}

struct BarcodeScannerRepresentable: UIViewRepresentable {
    var onBarcodeDetected: (Bool, String) -> Void
    
    func makeCoordinator() -> Coordinator {
        return Coordinator(onBarcodeDetected: onBarcodeDetected)
    }
    
    func makeUIView(context: Context) -> UIView {
        let view = UIView()
        context.coordinator.setupCaptureSession(for: view)
        return view
    }
    
    func updateUIView(_ uiView: UIView, context: Context) {}
    
    class Coordinator: NSObject, AVCaptureMetadataOutputObjectsDelegate {
        private let onBarcodeDetected: (Bool, String) -> Void
        private let captureSession = AVCaptureSession()
        
        init(onBarcodeDetected: @escaping (Bool, String) -> Void) {
            self.onBarcodeDetected = onBarcodeDetected
        }
        
        func setupCaptureSession(for view: UIView) {
            requestCameraPermission()
            
            guard let videoCaptureDevice = AVCaptureDevice.default(for: .video) else {
                print("Unable to access camera")
                return
            }
            
            do {
                // Limit frame rate to 10 FPS
                try videoCaptureDevice.lockForConfiguration()
                videoCaptureDevice.activeVideoMinFrameDuration = CMTimeMake(value: 1, timescale: 2)
                videoCaptureDevice.activeVideoMaxFrameDuration = CMTimeMake(value: 1, timescale: 2)
                videoCaptureDevice.unlockForConfiguration()
                
                let videoInput = try AVCaptureDeviceInput(device: videoCaptureDevice)
                if captureSession.canAddInput(videoInput) {
                    captureSession.addInput(videoInput)
                }
                
                let metadataOutput = AVCaptureMetadataOutput()
                if captureSession.canAddOutput(metadataOutput) {
                    captureSession.addOutput(metadataOutput)
                    metadataOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
                    metadataOutput.metadataObjectTypes = [.ean8, .ean13, .qr]
                }
                
                let previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
                previewLayer.videoGravity = .resizeAspectFill
                DispatchQueue.main.async {
                    previewLayer.frame = view.layer.bounds
                    view.layer.addSublayer(previewLayer)
                }
                
                DispatchQueue.global(qos: .userInitiated).async { [weak self] in
                    self?.captureSession.startRunning()
                }
            } catch {
                print("Error setting up camera: \(error)")
            }
        }
        
        func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
            if let metadataObject = metadataObjects.first as? AVMetadataMachineReadableCodeObject,
               let stringValue = metadataObject.stringValue {
                // 바코드를 인식한 경우
                DispatchQueue.main.async {
                    self.onBarcodeDetected(true, stringValue)
                }
            } else {
                // 바코드를 인식하지 못한 경우
                DispatchQueue.main.async {
                    self.onBarcodeDetected(false, "")
                }
            }
        }
        
        func requestCameraPermission() {
            switch AVCaptureDevice.authorizationStatus(for: .video) {
            case .authorized:
                break
            case .notDetermined:
                AVCaptureDevice.requestAccess(for: .video) { granted in
                    if !granted {
                        print("Camera access denied")
                    }
                }
            case .denied, .restricted:
                print("Camera access denied or restricted")
            default:
                break
            }
        }
    }
}
