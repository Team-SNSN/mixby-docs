//
//  NoteEditView.swift
//  Mixby-Booth
//
//  Created by Anthony on 11/13/25.
//

import SwiftUI
import UIKit

struct NoteEditView: View {
    @Binding var showAlert: Bool
    @Binding var isEditing: Bool
    
    @State private var val1: Int = 0
    @State private var val2: Int = 0
    @State private var val3: Int = 0
    
    var recipe: Recipe
    
    private var canSave: Bool {
        val1 > 0 && val2 > 0 && val3 > 0
    }
    
    var body: some View {
        VStack (spacing: 32) {
            Text("테이스팅 노트 작성")
                .font(.custom(Font.mixby, size: 16))
                .foregroundStyle(Color.white)
                .padding(8)
                .background(Capsule().fill(Color.white.opacity(0.1)))
                .padding(.top, -32)
            
            HStack (spacing: 16) {
                Spacer().frame(width: 38)
                
                Text("부족해요")
                    .font(.custom(Font.mixby, size: 12))
                    .foregroundStyle(Color.white.opacity(0.8))
                    .frame(width: 48)
                
                Spacer()
                
                Text("최고에요")
                    .font(.custom(Font.mixby, size: 13))
                    .foregroundStyle(Color.mixby.pink.opacity(0.8))
                    .frame(width: 48)
                
                Spacer()
                
                Text("과해요")
                    .font(.custom(Font.mixby, size: 12))
                    .foregroundStyle(Color.white.opacity(0.8))
                    .frame(width: 48)
            }
            
            SevenButtons(text: "당도", value: $val1)
            SevenButtons(text: "산미", value: $val2)
            SevenButtons(text: "알코올", value: $val3)
            
            Spacer()
            
            Button(action: saveNote) {
                Text("저장")
                    .font(.custom(Font.mixby, size: 20))
                    .foregroundStyle(Color.white)
                    .frame(width: DeviceManager.shared.screenWidth * 0.4, height: Dummy.tabbarHeight)
                    .mixbyGlass(cornerRadius: 100)
            }
            .buttonStyle(.plain)
            .opacity(canSave ? 1 : 0.45)
        }
        .padding(32)
        .onAppear {
            let values = NoteLoader.shared.getValue(name: recipe.english_name)
            val1 = values.val1
            val2 = values.val2
            val3 = values.val3
        }
    }

    private func saveNote() {
        guard canSave else {
            if NoteLoader.shared.hasNote(named: recipe.english_name) {
                NoteLoader.shared.removeNote(named: recipe.english_name)
                UINotificationFeedbackGenerator().notificationOccurred(.success)
                withAnimation { isEditing = false }
            } else {
                UINotificationFeedbackGenerator().notificationOccurred(.warning)
            }
            return
        }
        NoteLoader.shared.addOrUpdateNote(name: recipe.english_name, val1: val1, val2: val2, val3: val3)
        withAnimation { isEditing = false; showAlert = true }
    }
}


struct SevenButtons: View {
    var text: String = ""
    
    @Binding var value: Int
    
    var body: some View {
        HStack (alignment: .center, spacing: 16) {
            Text(text)
                .font(.custom(Font.mixby, size: 14))
                .foregroundStyle(Color.white)
                .frame(width: 38)
            
            VStack(spacing: 4) {
                GeometryReader { geo in
                    ZStack(alignment: .leading) {
                        Capsule()
                            .fill(Color.white.opacity(0.25))
                            .frame(height: 6)
                            .padding(.horizontal, 20)
                        
                        let stepWidth = (geo.size.width - 40) / 6
                        Circle()
                            .fill(Color.mixby.pink)
                            .frame(width: 20, height: 20)
                            .offset(x: CGFloat(value - 1) * stepWidth + 10)
                            .opacity(value == 0 ? 0 : 1)
                    }
                    .contentShape(Rectangle())
                    .gesture(
                        DragGesture(minimumDistance: 0)
                            .onChanged { gesture in
                                let x = max(0, min(gesture.location.x - 20, geo.size.width - 40))
                                let ratio = x / max(1, (geo.size.width - 40))
                                let continuousValue = 1 + ratio * 6
                                withAnimation(.linear(duration: 0.05)) {
                                    value = Int(round(continuousValue))
                                }
                            }
                            .onEnded { gesture in
                                let x = max(0, min(gesture.location.x - 20, geo.size.width - 40))
                                let ratio = x / max(1, (geo.size.width - 40))
                                let nearestStep = Int(round(1 + ratio * 6))
                                withAnimation(.spring(duration: 0.25)) {
                                    value = min(max(nearestStep, 1), 7)
                                }
                            }
                    )
                }
                .frame(height: 32)
                
                // Tick marks
                HStack {
                    ForEach(0..<7) { idx in
                        let isImp = (idx == 0 || idx == 3 || idx == 6)
                        Rectangle()
                            .fill(Color.white.opacity(isImp ? 0.8 : 0.4))
                            .frame(width: 1, height: isImp ? 8 : 6)
                        if idx != 6 { Spacer() }
                    }
                }
                .padding(.horizontal, 20)
            }
        }
        .frame(height: 48)
    }
}
