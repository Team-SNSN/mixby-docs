import SwiftUI

struct ProfileView: View {
    @Binding var isPresented: Bool
    
    @State private var nickname: String = ""
    @State private var selection1: Int = 0
    @State private var selection2: Int = 0
    
    let screenWidth = DeviceManager.shared.screenWidth
    
    var body: some View {
        ZStack {
            AnimatedBackground()
            
            VStack (spacing: 16) {
                MixbyDivider()
                    .padding(.horizontal, -16)
                    .offset(y: 2)
                
                Text("닉네임")
                    .font(.custom(Font.mixby, size: 16))
                    .foregroundStyle(Color.white)
                    .padding(8)
                    .background(Capsule().fill(Color.white.opacity(0.1)))
                    .padding(.horizontal, 16)
                
                TextField("", text: limitedNicknameBinding)
                    .font(.custom(Font.mixby, size: 16))
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 12)
                            .fill(Color.white.opacity(0.1))
                    )
                    .foregroundColor(.white)
                    .padding(.horizontal, 16)
                
                MixbyDivider()
                
                Text("성별")
                    .font(.custom(Font.mixby, size: 16))
                    .foregroundStyle(Color.white)
                    .padding(8)
                    .background(Capsule().fill(Color.white.opacity(0.1)))
                    .padding(.horizontal, 16)
                
                MixbyMultiSelector(selection: $selection1, options: ["남성", "여성"])
                    .padding(.horizontal, 16)
                
                MixbyDivider()
                
                Text("선호하는 맛")
                    .font(.custom(Font.mixby, size: 16))
                    .foregroundStyle(Color.white)
                    .padding(8)
                    .background(Capsule().fill(Color.white.opacity(0.1)))
                    .padding(.horizontal, 16)
                
                MixbyMultiSelector(selection: $selection2, options: ["알코올 맛", "단 맛", "상큼한 맛"])
                    .padding(.horizontal, 16)
                
                Spacer()
                
                Text("저장")
                    .font(.custom(Font.mixby, size: 20))
                    .foregroundStyle(Color.white)
                    .frame(width: DeviceManager.shared.screenWidth * 0.4, height: Dummy.tabbarHeight)
                    .mixbyGlass(cornerRadius: 100)
                    .onTapGesture {
                        SettingsManager.shared.save(username: nickname, option1: selection1, option2: selection2)
                        
                        let coor = LocationManager.shared.currentCoordinates()
                        
                        withAnimation { isPresented = false }
                    }
            }
        }
        .toolbar {
            ToolbarItem(placement: .principal) {
                Text("프로필")
                    .font(.custom(Font.mixby, size: 16))
                    .foregroundColor(.white)
            }
        }
        .onAppear{
            nickname = String(SettingsManager.shared.loadUsername().prefix(10))
            selection1 = SettingsManager.shared.loadOption1()
            selection2 = SettingsManager.shared.loadOption2()
        }
    }

    private var limitedNicknameBinding: Binding<String> {
        Binding(
            get: { nickname },
            set: { nickname = String($0.prefix(10)) }
        )
    }
}


struct MixbyMultiSelector: View {
    
    @Binding var selection: Int
    var options: [String]
    
    var body: some View {
        GeometryReader { geo in
            let totalWidth = geo.size.width
            let count = CGFloat(options.count)

            let selectedWidth = totalWidth * 2 / (count + 1)
            let unselectedWidth = totalWidth * 1 / (count + 1)
            
            HStack(spacing: 0) {
                ForEach(options.indices, id: \.self) { idx in
                    Button {
                        withAnimation(.spring(duration: 0.25)) {
                            selection = idx
                        }
                    } label: {
                        ZStack {
                            Rectangle()
                                .fill(
                                    selection == idx
                                    ? Color.mixby.pink.opacity(0.6)
                                    : Color.white.opacity(0.1)
                                )
                            
                            Text(options[idx])
                                .font(.custom(Font.mixby, size: 16))
                                .foregroundColor(.white)
                        }
                        .frame(width: selection == idx ? selectedWidth : unselectedWidth)
                    }
                    .buttonStyle(.plain)
                }
            }
            .clipShape(RoundedRectangle(cornerRadius: 16))
        }
        .frame(height: 60)
    }
}
