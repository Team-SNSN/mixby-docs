//
//  CreditView.swift
//  Mixby-Booth
//
//  Created by Anthony on 10/2/25.
//

import SwiftUI

struct CreditView: View {
    @Binding var isPresented: Bool
    
    var body: some View {
        ZStack {
            AnimatedBackground()
            
            VStack {
                MixbyDivider()
                    .padding(.horizontal, -16)
                    .offset(y: 2)
                
                Spacer()
                
                VStack(spacing: 12) {
                    
                    Spacer()
                    
                    Text("이용해주셔서 감사합니다!")
                        .font(.custom(Font.mixby, size: 20))
                        .foregroundStyle(Color.mixby.pink)
                        .padding(32)
                    
                    Button {
                        if let url = URL(string: "google.com") {
                            UIApplication.shared.open(url)
                        }
                    } label: {
                        Text("버그 및 피드백 제출")
                            .font(.custom(Font.mixby, size: 16))
                            .foregroundStyle(.black)
                            .padding(.vertical, 10)
                            .padding(.horizontal, 20)
                            .background(Color.white.opacity(0.9))
                            .clipShape(Capsule())
                            .shadow(radius: 4)
                    }
                    .padding(.top, 8)
                    
                    Spacer()
                    Spacer()
                    
                    HStack {
                        Image(systemName: "c.circle")
                            .font(.system(size: 14))
                            .foregroundStyle(.white.opacity(0.8))
                        
                        Text("팀 섬놈설놈  2025")
                            .font(.system(size: 14))
                            .foregroundStyle(.white.opacity(0.8))
                    }
                }
                .padding(16)
                
                Spacer()
            }
        }
        .toolbar {
            ToolbarItem(placement: .principal) {
                Text("Mixby")
                    .font(.custom(Font.mixby, size: 20))
                    .foregroundStyle(.white)
            }
        }
    }
}
