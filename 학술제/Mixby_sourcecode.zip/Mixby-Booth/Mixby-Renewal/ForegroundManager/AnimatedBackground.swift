//
//  AnimatedBackground.swift
//  Mixby-Booth
//
//  Created by Anthony on 9/29/25.
//

import SwiftUI

struct AnimatedBackground: View {
    var body: some View {
        ZStack {
            Color.mixby.black
            
            MetalMetaballsView()
                .opacity(0.4)
                .blur(radius: 12)
            
            LinearGradient(
                gradient: Gradient(colors: [
                    Color(hue: 0.75, saturation: 0.4, brightness: 0.2),
                    Color(hue: 0.82, saturation: 0.6, brightness: 0.1)
                ]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .opacity(0.8)
        }
        .ignoresSafeArea()
    }
}

