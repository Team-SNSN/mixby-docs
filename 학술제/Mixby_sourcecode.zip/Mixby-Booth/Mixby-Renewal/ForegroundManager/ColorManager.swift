//
//  ColorManager.swift
//  Mixby-Booth
//
//  Created by Anthony on 9/17/25.
//

import SwiftUI

extension Color {
    static let mixby = MixbyColors()
}

struct MixbyColors {
    let black = Color(red: 0.10, green: 0.06, blue: 0.00)
    let pink = Color(red: 0.94, green: 0.86, blue: 0.90)
    let wine = Color(red: 0.35, green: 0.11, blue: 0.13)
    let purple = Color(red: 0.20, green: 0.05, blue: 0.21)
    let brown = Color(red: 0.57, green: 0.31, blue: 0.02)
    
    let accent = Color(red: 0.57, green: 0.31, blue: 0.02)
}
