//
//  FontsManager.swift
//  mixby2
//
//  Created by Anthony on 11/27/24.
//

import SwiftUI

extension Font {
    static let mixby: String = "GyeonggiBatangBOTF"
}
