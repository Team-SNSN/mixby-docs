//
//  CustomAssets.swift
//  Mixby-Renewal
//
//  Created by Anthony on 11/9/25.
//

import SwiftUI

extension View {
    func vignetteBlur() -> some View {
        self
            .overlay(
                RadialGradient(
                    gradient: Gradient(colors: [
                        Color.black.opacity(0),
                        Color.black.opacity(0.6)
                    ]),
                    center: .center,
                    startRadius: 50,
                    endRadius: 500
                )
            )
            .mask(
                Circle()
                    .fill(
                        RadialGradient(
                            gradient: Gradient(colors: [
                                Color.white,
                                Color.white.opacity(0)
                            ]),
                            center: .center,
                            startRadius: 200,
                            endRadius: 500
                        )
                    )
            )
            .overlay(
                self
                    .blur(radius: 20)
                    .mask(
                        RadialGradient(
                            gradient: Gradient(colors: [
                                Color.black.opacity(0),
                                Color.black.opacity(1)
                            ]),
                            center: .center,
                            startRadius: 150,
                            endRadius: 500
                        )
                    )
            )
    }
}

struct MixbyDivider: View {
    var body: some View {
        Rectangle()
            .frame(height: 1)
            .foregroundColor(.white.opacity(0.1))
            .padding(.horizontal, 16)
//            .padding(.top, 16)
    }
}


struct SectionTitle: View {
    var text: String = "default"
    var padding: CGFloat = 0
    
    var body: some View {
        Text(text)
            .font(.custom(Font.mixby, size: 16))
            .foregroundStyle(Color.white)
            .padding(8)
            .background(Capsule().fill(Color.white.opacity(0.1)))
            .padding(.vertical, padding)
    }
}
