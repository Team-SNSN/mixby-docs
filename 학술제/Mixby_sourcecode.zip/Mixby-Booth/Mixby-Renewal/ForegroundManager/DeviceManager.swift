//
//  DeviceManager.swift
//  Mixby-Renewal
//
//  Created by Anthony on 10/15/25.
//

import Foundation
import UIKit

enum DeviceType {
    case iPhone
    case iPad
}

final class DeviceManager {
    // MARK: - Singleton
    static let shared = DeviceManager()

    // Cached metrics (updated on rotation/scene changes)
    private var _screenWidth: CGFloat
    private var _screenHeight: CGFloat

    private init() {
        let initialBounds = DeviceManager.currentScreenBounds()
        self._screenWidth = initialBounds.size.width
        self._screenHeight = initialBounds.size.height
        startObserving()
    }

    // MARK: - Public Screen Metrics
    var screenWidth: CGFloat { _screenWidth }
    var screenHeight: CGFloat { _screenHeight }

    // MARK: - Device Type
    var isPad: Bool {
        if UIDevice.current.userInterfaceIdiom == .pad { return true }
        let minSide = min(screenWidth, screenHeight)
        return minSide >= 768
    }

    var isPhone: Bool {
        if UIDevice.current.userInterfaceIdiom == .phone { return true }
        let maxSide = max(screenWidth, screenHeight)
        return maxSide < 1024
    }

    var currentDevice: DeviceType {
        isPad ? .iPad : .iPhone
    }

    // MARK: - Observing & Updates
    @MainActor private func updateScreenMetrics() {
        let bounds = DeviceManager.currentScreenBounds()
        self._screenWidth = bounds.size.width
        self._screenHeight = bounds.size.height
    }

    private func startObserving() {
        UIDevice.current.beginGeneratingDeviceOrientationNotifications()
        NotificationCenter.default.addObserver(forName: UIDevice.orientationDidChangeNotification, object: nil, queue: .main) { [weak self] _ in
            self?.updateScreenMetrics()
        }
        NotificationCenter.default.addObserver(forName: UIApplication.didChangeStatusBarOrientationNotification, object: nil, queue: .main) { [weak self] _ in
            self?.updateScreenMetrics()
        }
        NotificationCenter.default.addObserver(forName: UIWindowScene.didActivateNotification, object: nil, queue: .main) { [weak self] _ in
            self?.updateScreenMetrics()
        }
    }

    // MARK: - Helpers
    private static func currentScreenBounds() -> CGRect {
        // Prefer active windowScene's key window bounds
        if let scene = UIApplication.shared.connectedScenes
            .compactMap({ $0 as? UIWindowScene })
            .first(where: { $0.activationState == .foregroundActive }),
           let window = scene.windows.first(where: { $0.isKeyWindow }) ?? scene.windows.first {
            return window.bounds
        }
        return UIScreen.main.bounds
    }
}

// Example: let device = DeviceManager.shared.currentDevice
// Example: let value = (DeviceManager.shared.currentDevice == .iPhone) ? 1 : 2
