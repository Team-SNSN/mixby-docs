import SwiftUI
import MetalKit

// Helper function to convert SwiftUI Color to SIMD4<Float>
func simdColor(from color: Color) -> SIMD4<Float> {
    let uiColor = UIColor(color)
    var red: CGFloat = 0
    var green: CGFloat = 0
    var blue: CGFloat = 0
    var alpha: CGFloat = 0
    uiColor.getRed(&red, green: &green, blue: &blue, alpha: &alpha)
    return SIMD4<Float>(Float(red), Float(green), Float(blue), Float(alpha))
}

struct MetalMetaballsView: UIViewRepresentable {
    func makeUIView(context: Context) -> MTKView {
        let view = MTKView()
        view.device = MTLCreateSystemDefaultDevice()
        view.clearColor = MTLClearColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.0)
        view.isOpaque = false
        view.delegate = context.coordinator
        return view
    }

    func updateUIView(_ uiView: MTKView, context: Context) {}

    func makeCoordinator() -> Renderer {
        Renderer(metaballCount: 10)
    }
}

struct Metaball {
    var position: SIMD2<Float>
    var velocity: SIMD2<Float>
    var radius: Float
}

class Renderer: NSObject, MTKViewDelegate {
    let metaballCount: Int
    let radiusRange: ClosedRange<Float> = 0.2...0.25
    let speedRange: ClosedRange<Float> = 0.0005...0.003
    
    var screenBoundsX: Float = 1.0
    var screenBoundsY: Float = 1.0

    var device: MTLDevice!
    var commandQueue: MTLCommandQueue!
    var pipelineState: MTLRenderPipelineState!

    var time: Float = 0

    var metaballs: [Metaball] = []
  
    init(metaballCount: Int) {
        self.metaballCount = metaballCount

        guard let device = MTLCreateSystemDefaultDevice() else {
            fatalError("❌ Metal device not available")
        }
        self.device = device
        commandQueue = device.makeCommandQueue()

        guard let library = device.makeDefaultLibrary() else {
            fatalError("❌ Failed to create default Metal library")
        }
        guard let vertexFunction = library.makeFunction(name: "vertexShader") else {
            fatalError("❌ Failed to load vertex function 'vertexShader'")
        }
        guard let fragmentFunction = library.makeFunction(name: "metaballFragment") else {
            fatalError("❌ Failed to load fragment function 'metaballFragment'")
        }

        let pipelineDescriptor = MTLRenderPipelineDescriptor()
        pipelineDescriptor.vertexFunction = vertexFunction
        pipelineDescriptor.fragmentFunction = fragmentFunction
        pipelineDescriptor.colorAttachments[0].pixelFormat = .bgra8Unorm
        pipelineDescriptor.colorAttachments[0].isBlendingEnabled = true
        pipelineDescriptor.colorAttachments[0].rgbBlendOperation = .add
        pipelineDescriptor.colorAttachments[0].alphaBlendOperation = .add
        pipelineDescriptor.colorAttachments[0].sourceRGBBlendFactor = .sourceAlpha
        pipelineDescriptor.colorAttachments[0].sourceAlphaBlendFactor = .sourceAlpha
        pipelineDescriptor.colorAttachments[0].destinationRGBBlendFactor = .oneMinusSourceAlpha
        pipelineDescriptor.colorAttachments[0].destinationAlphaBlendFactor = .oneMinusSourceAlpha

        do {
            pipelineState = try device.makeRenderPipelineState(descriptor: pipelineDescriptor)
        } catch let error {
            fatalError("❌ Failed to create pipeline state: \(error.localizedDescription)")
        }

        super.init()
        metaballs = []

        for _ in 0..<metaballCount {
            let position = SIMD2<Float>(Float.random(in: -1...1), Float.random(in: -1...1))
            
            // Create a velocity with a random direction and speed
            let angle = Float.random(in: 0...(2 * .pi))
            let angleOffset = Float.random(in: -0.3...0.3)
            let adjustedAngle = angle + angleOffset
            let speed = Float.random(in: speedRange)
            let velocity = SIMD2<Float>(cos(adjustedAngle), sin(adjustedAngle)) * speed

            // Radius randomly between 0.18 and 0.28
            let radius = Float.random(in: radiusRange)

            metaballs.append(Metaball(position: position, velocity: velocity, radius: radius))
        }
    }

    func draw(in view: MTKView) {
        guard let drawable = view.currentDrawable,
              let descriptor = view.currentRenderPassDescriptor else { return }

        time += 0.01

        screenBoundsX = Float(view.drawableSize.width) / Float(view.drawableSize.height)
        screenBoundsY = 1.0

        let commandBuffer = commandQueue.makeCommandBuffer()
        let commandEncoder = commandBuffer?.makeRenderCommandEncoder(descriptor: descriptor)

        commandEncoder?.setRenderPipelineState(pipelineState)
        commandEncoder?.setFragmentBytes(&time, length: MemoryLayout<Float>.size, index: 0)

        var resolution = vector_float2(Float(view.drawableSize.width), Float(view.drawableSize.height))
        commandEncoder?.setFragmentBytes(&resolution, length: MemoryLayout<vector_float2>.size, index: 1)

        for i in 0..<metaballs.count {
            var ball = metaballs[i]
            ball.position += ball.velocity

            if ball.position.x > screenBoundsX || ball.position.x < -screenBoundsX {
                ball.velocity.x *= -1
            }
            if ball.position.y > screenBoundsY || ball.position.y < -screenBoundsY {
                ball.velocity.y *= -1
            }

            metaballs[i] = ball
        }

        var metaballData: [SIMD4<Float>] = metaballs.map {
            SIMD4<Float>($0.position.x, $0.position.y, $0.radius, 0)
        }
        commandEncoder?.setFragmentBytes(&metaballData, length: MemoryLayout<SIMD4<Float>>.stride * metaballData.count, index: 2)
        var numBalls = UInt32(metaballs.count)
        commandEncoder?.setFragmentBytes(&numBalls, length: MemoryLayout<UInt32>.size, index: 3)

        // Set the color to be passed into the fragment shader
        var ballColor = simdColor(from: Color.mixby.wine)
        commandEncoder?.setFragmentBytes(&ballColor, length: MemoryLayout<SIMD4<Float>>.size, index: 4)

        var center = vector_float2(Float(view.drawableSize.width / 2), Float(view.drawableSize.height / 2))
        var blurRadius: Float = 40.0
        commandEncoder?.setFragmentBytes(&center, length: MemoryLayout<vector_float2>.size, index: 5)
        commandEncoder?.setFragmentBytes(&blurRadius, length: MemoryLayout<Float>.size, index: 6)

        commandEncoder?.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: 6)

        commandEncoder?.endEncoding()
        commandBuffer?.present(drawable)
        commandBuffer?.commit()
    }

    func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) {}
}
