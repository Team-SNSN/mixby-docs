//
//  SplashScreenView.swift
//  Mixby-Renewal
//
//  Created by Codex on 12/28/25.
//

import SwiftUI
import WebKit

struct SplashScreenView: View {
    var body: some View {
        
        let loadingTexts = [
            "마티니 글래스 말리는 중..",
            "지거 닦는 중..",
            "창 밖으로 날씨 확인하는 중..",
            "냉장고에서 재료 찾는 중..",
            "레몬 껍질 벗기는 중..",
            "토치 건전지 교체 중..",
            "수염 만지작 거리는 중..",
            "레시피 골똘히 생각하는 중.."
        ]
        ZStack {
            AnimatedBackground().ignoresSafeArea()
            
            VStack {
                TransparentGIFView(gifName: "loading")
                    .frame(width: 120, height: 120)
                
                Text(loadingTexts[Int.random(in: 0..<loadingTexts.count)])
                    .font(.custom(Font.mixby, size: 16))
                    .foregroundColor(.white)
                
            }
        }
    }
}
