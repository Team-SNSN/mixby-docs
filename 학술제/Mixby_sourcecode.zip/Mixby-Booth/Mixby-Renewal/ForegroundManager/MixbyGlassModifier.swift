//
//  MixbyGlassModifier.swift
//  Mixby-Booth
//
//  Created by Anthony on 9/24/25.
//


import SwiftUI
import UIKit

struct VisualEffectBlur: UIViewRepresentable {
    var effect: UIVisualEffect?
    
    func makeUIView(context: Context) -> UIVisualEffectView {
        let view = UIVisualEffectView()
        view.effect = effect
        return view
    }
    
    func updateUIView(_ uiView: UIVisualEffectView, context: Context) {
        uiView.effect = effect
    }
}

struct MixbyGlassModifier: ViewModifier {
    @State private var angle: Angle = .zero
    
    var gradientType: Int = 1
    var cornerRadius: CGFloat = 32
    
    private let gradientColors: [[Color]] = [
        [.white.opacity(0.5), .clear],
        [.white.opacity(0.5), .clear, .clear, .white.opacity(0.6)]
    ]
    
    private let gradientPoints: [[UnitPoint]] = [
        [.top, .bottom],
        [.topLeading, .bottomTrailing]
    ]
    
    func body(content: Content) -> some View {
        content
            .background(.ultraThinMaterial.opacity(0.7))
            .clipShape(RoundedRectangle(cornerRadius: cornerRadius))
    }
}

extension View {
    func mixbyGlass(cornerRadius: CGFloat) -> some View {
        self.modifier(MixbyGlassModifier(cornerRadius: cornerRadius))
    }
}
