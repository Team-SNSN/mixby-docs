//
//  PersonaLoader.swift
//  Mixby-Booth
//
//  Created by Anthony on 11/14/25.
//

import Foundation

final class PersonaLoader {

    static let shared = PersonaLoader()

    private init() {}

    private let personaKey = "saved_persona"

    var savedPersona: String {
        UserDefaults.standard.string(forKey: personaKey) ?? ""
    }

    private func savePersona(_ text: String) {
        UserDefaults.standard.set(text, forKey: personaKey)
    }

    struct UserData: Codable {
        let name: String
        let gender: String
        let favoriteTaste: String
    }

    struct TastingData: Codable {
        let code: String
        let drinkDate: String
        let eval: Int
        let sweetness: Int
        let sourness: Int
        let alcohol: Int
    }

    struct PersonaRequest: Codable {
        let user_data: [UserData]
        let tasting_data: [TastingData]
    }

    struct PersonaResponse: Codable {
        let success: Bool
        let message: String
        let data: PersonaData
    }

    struct PersonaData: Codable {
        let persona: String
    }

    func requestPersona(user: UserData, tastings: [TastingData], completion: @escaping (PersonaData?) -> Void) {

        let url = URL(string: ServerURL.persona)!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let body = PersonaRequest(
            user_data: [user],
            tasting_data: tastings
        )

        guard let encoded = try? JSONEncoder().encode(body) else {
            completion(nil)
            return
        }

        request.httpBody = encoded

        URLSession.shared.dataTask(with: request) { data, _, _ in
            guard let data else {
                completion(nil)
                return
            }

            do {
                let decoded = try JSONDecoder().decode(PersonaResponse.self, from: data)
                self.savePersona(decoded.data.persona)
                completion(decoded.data)
            } catch {
                print("Persona decode error:", error)
                completion(nil)
            }
        }.resume()
    }
}
