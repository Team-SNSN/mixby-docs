//
//  RemoteImageView.swift
//  Mixby-Renewal
//
//  Created by Codex on 12/28/25.
//

import SwiftUI

struct RemoteImageView: View {
    private let baseURLs = [ServerURL.d_img_header, ServerURL.r_img_header]

    let imageType: Int
    let code: String
    let scaling: ContentMode
    let targetPixelDimension: CGFloat?

    init(imageType: Int,
         code: String,
         scaling: ContentMode = .fit,
         targetPixelDimension: CGFloat? = nil) {
        self.imageType = imageType
        self.code = code
        self.scaling = scaling
        self.targetPixelDimension = targetPixelDimension
    }

    var body: some View {
        Group {
            if let url = composedURL {
                AsyncImage(url: url, transaction: Transaction(animation: .easeInOut)) { phase in
                    switch phase {
                    case .empty:
                        placeholder
                    case .success(let image):
                        image
                            .resizable()
                            .aspectRatio(contentMode: scaling)
                            .transition(.opacity)
                    case .failure:
                        failure
                    @unknown default:
                        failure
                    }
                }
            } else {
                failure
            }
        }
    }

    private var placeholder: some View {
        ZStack {
            Color.clear
            ProgressView()
                .progressViewStyle(.circular)
                .tint(.white)
        }
    }

    private var failure: some View {
        Image(systemName: "xmark.circle")
            .resizable()
            .aspectRatio(contentMode: .fit)
            .foregroundColor(.red)
    }

    private var composedURL: URL? {
        guard baseURLs.indices.contains(imageType) else { return nil }
        let urlString = baseURLs[imageType] + code
        return URL(string: urlString)
    }
}

