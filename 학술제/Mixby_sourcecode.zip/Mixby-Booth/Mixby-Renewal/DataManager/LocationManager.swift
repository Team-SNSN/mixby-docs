//
//  LocationManager.swift
//  Mixby-Booth
//
//  Created by Anthony on 11/14/25.
//

import Foundation
import CoreLocation

final class LocationManager: NSObject, CLLocationManagerDelegate {

    static let shared = LocationManager()

    private let manager = CLLocationManager()

    @Published private(set) var latitude: Double?
    @Published private(set) var longitude: Double?
    private var singleLocationCallback: ((Double, Double) -> Void)?

    private override init() {
        super.init()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBest
    }

    func requestPermission() {
        manager.requestWhenInUseAuthorization()
    }

    func startUpdating() {
        manager.startUpdatingLocation()
    }

    func stopUpdating() {
        manager.stopUpdatingLocation()
    }

    // 한 번만 현재 위치 요청
    func requestSingleLocation(_ completion: @escaping (Double, Double) -> Void) {
        singleLocationCallback = completion
        manager.requestLocation()
    }

    // 현재 저장된 위도·경도 즉시 반환
    func currentCoordinates() -> (Double?, Double?) {
        return (latitude, longitude)
    }

    // MARK: - CLLocationManagerDelegate
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last else { return }

        let lat = location.coordinate.latitude
        let lon = location.coordinate.longitude

        latitude = lat
        longitude = lon

        singleLocationCallback?(lat, lon)
        singleLocationCallback = nil
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Location error:", error.localizedDescription)
    }
}
