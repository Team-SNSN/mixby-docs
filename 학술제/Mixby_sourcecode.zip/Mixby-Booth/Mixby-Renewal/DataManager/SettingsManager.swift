//
//  SettingsManager.swift
//  Mixby-Booth
//
//  Created by Anthony on 11/14/25.
//

import Foundation

final class SettingsManager {

    static let shared = SettingsManager()

    private init() {}

    private let usernameKey = "settings_username"
    private let option1Key = "settings_option1"
    private let option2Key = "settings_option2"

    func save(username: String, option1: Int, option2: Int) {
        UserDefaults.standard.set(username, forKey: usernameKey)
        UserDefaults.standard.set(option1, forKey: option1Key)
        UserDefaults.standard.set(option2, forKey: option2Key)
    }

    func loadUsername() -> String {
        UserDefaults.standard.string(forKey: usernameKey) ?? ""
    }

    func loadOption1() -> Int {
        UserDefaults.standard.integer(forKey: option1Key)
    }

    func loadOption2() -> Int {
        UserDefaults.standard.integer(forKey: option2Key)
    }
}
