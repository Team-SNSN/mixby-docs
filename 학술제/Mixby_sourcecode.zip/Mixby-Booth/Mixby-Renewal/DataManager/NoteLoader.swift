//
//  NoteLoader.swift
//  Mixby-Booth
//
//  Created by Anthony on 11/13/25.
//

import SwiftUI

struct Note: Codable, Identifiable {
    var id: String { name }
    let code: String
    let name: String
    let eval: Int
    let val1: Int
    let val2: Int
    let val3: Int
}

extension Note {
    func toTastingData() -> PersonaLoader.TastingData {
        return PersonaLoader.TastingData(
            code: self.code,
            drinkDate: "2026-01-01",
            eval: self.eval,
            sweetness: self.val1,
            sourness: self.val2,
            alcohol: self.val3
        )
    }
}

@MainActor
final class NoteLoader: ObservableObject {
    static let shared = NoteLoader()
    
    @Published var notedRecipes: [Note] = [] {
        didSet { save() }
    }
    
    private init() {
        load()
    }
    
    private func load() {
        if let data = UserDefaults.standard.data(forKey: "NotedRecipes"),
           let decoded = try? JSONDecoder().decode([Note].self, from: data) {
            notedRecipes = decoded
        } else {
            notedRecipes = []
        }
    }
    
    private func save() {
        if let encoded = try? JSONEncoder().encode(notedRecipes) {
            UserDefaults.standard.set(encoded, forKey: "NotedRecipes")
        }
    }
    
    func getValue(name: String) -> (val1: Int, val2: Int, val3: Int) {
        if let note = notedRecipes.first(where: { $0.name == name }) {
            return (note.val1, note.val2, note.val3)
        } else {
            return (0, 0, 0)
        }
    }
    
    func addOrUpdateNote(name: String, val1: Int, val2: Int, val3: Int) {
        if let index = notedRecipes.firstIndex(where: { $0.name == name }) {
            // Update existing note
            notedRecipes[index] = Note(code: notedRecipes[index].code,
                                       name: name,
                                       eval: (val1 + val2 + val3) / 3,
                                       val1: val1,
                                       val2: val2,
                                       val3: val3)
        } else {
            // Create new note with empty code (or default)
            let newNote = Note(code: UUID().uuidString,
                               name: name,
                               eval: (val1 + val2 + val3) / 3,
                               val1: val1,
                               val2: val2,
                               val3: val3)
            notedRecipes.append(newNote)
        }
    }
    
    func removeNote(_ note: Note) {
        notedRecipes.removeAll { $0.id == note.id }
    }
    
    func removeNote(named name: String) {
        notedRecipes.removeAll { $0.name == name }
    }
    
    func hasNote(named name: String) -> Bool {
        notedRecipes.contains { $0.name == name }
    }
    
    func clearAll() {
        notedRecipes.removeAll()
    }
}
