//
//  UserData.swift
//  Mixby-Booth
//
//  Created by Anthony on 9/24/25.
//


import Foundation

class UserData: ObservableObject {
    static let shared = UserData()

    @Published var user_id: String = ""
    @Published var owned_drinks: [String] = []

    private init() {}

    func loadFromAppStorage() {
        if let storedUserId = UserDefaults.standard.string(forKey: "user_id") {
            self.user_id = storedUserId
        }
        if let storedDrinks = UserDefaults.standard.array(forKey: "owned_drinks") as? [String] {
            self.owned_drinks = storedDrinks
        }
    }

    func saveToAppStorage() {
        UserDefaults.standard.set(self.user_id, forKey: "user_id")
        UserDefaults.standard.set(self.owned_drinks as [String], forKey: "owned_drinks")
    }
}
