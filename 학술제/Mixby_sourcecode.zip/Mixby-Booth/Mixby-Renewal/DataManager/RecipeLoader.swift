//
//  RecipeLoader.swift
//  Mixby-Booth
//
//  Created by Anthony on 9/29/25.
//

import Foundation

struct Recipe: Codable {
    let english_name: String
    let korean_name: String
    let code: String
    let ingredients: [Ingredient]
    let instructions: [String]
    let tag1: String?
    let tag2: String?
}

final class RecipeLoader {
    static let shared = RecipeLoader()
    private init() {}

    private var recipeCache: [String: Recipe] = [:]

    func load(code: String) async throws -> Recipe {
        if let cached = recipeCache[code] {
            return cached
        }

        let urlString = ServerURL.r_code_search + code
        guard let url = URL(string: urlString) else {
            throw URLError(.badURL)
        }

        let (data, _) = try await URLSession.shared.data(from: url)
        let recipe = try JSONDecoder().decode(Recipe.self, from: data)
        recipeCache[code] = recipe
        return recipe
    }

    func fetch(fromCode code: String, completion: @escaping (Result<Recipe, Error>) -> Void) {
        if let cached = recipeCache[code] {
            completion(.success(cached))
            return
        }

        let urlString = ServerURL.r_code_search + code
        guard let url = URL(string: urlString) else {
            completion(.failure(NSError(domain: "Invalid URL", code: -1)))
            return
        }

        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }

            guard let data = data else {
                completion(.failure(NSError(domain: "No data", code: -2)))
                return
            }

            do {
                let decoder = JSONDecoder()
                let recipe = try decoder.decode(Recipe.self, from: data)
                self.recipeCache[code] = recipe
                completion(.success(recipe))
            } catch {
                completion(.failure(error))
            }
        }

        task.resume()
    }
}


final class RecipeDict: ObservableObject {
    static let shared = RecipeDict()
    private init() {}

    @Published private(set) var recipes: [Recipe] = []

    func fetchdict(from urlString: String, completion: ((Bool) -> Void)? = nil) {
        guard let url = URL(string: urlString) else {
            print("❌ 잘못된 URL: \(urlString)")
            completion?(false)
            return
        }

        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                print("❌ 네트워크 에러: \(error.localizedDescription)")
                completion?(false)
                return
            }

            guard let data = data else {
                print("⚠️ 데이터가 비어있습니다.")
                completion?(false)
                return
            }

            do {
                let decoded = try JSONDecoder().decode([Recipe].self, from: data)
                DispatchQueue.main.async {
                    self.recipes = decoded
//                    print("RecipeDict: \(decoded.count)개의 레시피를 불러왔습니다.")
                    completion?(true)
                }
            } catch {
                print("RecipeDict: JSON 디코딩 실패: \(error.localizedDescription)")
                completion?(false)
            }
        }

        task.resume()
    }

    func recipe(forCode code: String) -> Recipe? {
        return recipes.first { $0.code == code }
    }

    func recipe(forEnglishName name: String) -> Recipe? {
        return recipes.first { $0.english_name == name }
    }
}



@MainActor
final class OwnedRecipeManager: ObservableObject {
    static let shared = OwnedRecipeManager()
    
    @Published var writtenRecipe: [String] = [] {
        didSet { save() }
    }
    
    @Published var ownedRecipesAll: [String] = [] {
        didSet { save() }
    }

    @Published var ownedRecipesSome: [String] = [] {
        didSet { save() }
    }

    @Published var ownedRecipesNone: [String] = [] {
        didSet { save() }
    }
    
    private let userDefaultsKeyAll = "OwnedRecipesAll"
    private let userDefaultsKeySome = "OwnedRecipesSome"
    private let userDefaultsKeyNone = "OwnedRecipesNone"
    
    private init() {
        load()
    }
    
    private func load() {
        if let dataAll = UserDefaults.standard.data(forKey: userDefaultsKeyAll),
           let decodedAll = try? JSONDecoder().decode([String].self, from: dataAll) {
            ownedRecipesAll = decodedAll
        }
        if let dataSome = UserDefaults.standard.data(forKey: userDefaultsKeySome),
           let decodedSome = try? JSONDecoder().decode([String].self, from: dataSome) {
            ownedRecipesSome = decodedSome
        }
        if let dataNone = UserDefaults.standard.data(forKey: userDefaultsKeyNone),
           let decodedNone = try? JSONDecoder().decode([String].self, from: dataNone) {
            ownedRecipesNone = decodedNone
        }
    }
    
    private func save() {
        if let encodedAll = try? JSONEncoder().encode(ownedRecipesAll) {
            UserDefaults.standard.set(encodedAll, forKey: userDefaultsKeyAll)
        }
        if let encodedSome = try? JSONEncoder().encode(ownedRecipesSome) {
            UserDefaults.standard.set(encodedSome, forKey: userDefaultsKeySome)
        }
        if let encodedNone = try? JSONEncoder().encode(ownedRecipesNone) {
            UserDefaults.standard.set(encodedNone, forKey: userDefaultsKeyNone)
        }
    }
    
    func addRecipe(_ recipe: String) {
        if !ownedRecipesAll.contains(recipe) {
            ownedRecipesAll.append(recipe)
        }
    }
    
    func removeRecipe(_ recipe: String) {
        ownedRecipesAll.removeAll { $0 == recipe }
        ownedRecipesSome.removeAll { $0 == recipe }
        ownedRecipesNone.removeAll { $0 == recipe }
    }
    
    func addWrittenRecipe(_ recipe: String) {
        if !writtenRecipe.contains(recipe) {
            writtenRecipe.append(recipe)
        }
    }

    func removeWrittenRecipe(_ recipe: String) {
        writtenRecipe.removeAll { $0 == recipe }
    }
    
    func clearAll() {
        ownedRecipesAll.removeAll()
        ownedRecipesSome.removeAll()
        ownedRecipesNone.removeAll()
    }

    var writtenFullRecipes: [String] {
        ownedRecipesAll.filter { writtenRecipe.contains($0) }
    }
    
    func getRecipeByCode(_ code: String) -> Recipe? {
        return RecipeDict.shared.recipes.first(where: { $0.code == code })
    }
    
    func getIngredientRatio(recipe: Recipe) -> (ownedCount: Float, totalCount: Float) {
        let recipeIngredients = recipe.ingredients
        let totalCount = recipeIngredients.count
        
        let ownedIngs = OwnedIngredientsManager.shared.ownedIngredients
        let ownedDrinks = OwnedDrinksManager.shared.ownedDrinks
        
        let ownedIngsCount = recipeIngredients.filter { ownedIngs.contains($0.code) }.count
        let ownedDrinksCount = recipeIngredients.filter { ingredient in
            ownedDrinks.contains(where: { $0.baseCode == ingredient.code })
        }.count
        
        let ownedCount = ownedIngsCount + ownedDrinksCount
        
        return (Float(ownedCount), Float(totalCount))
    }
    
    func fetchAvailableRecipes() {
        ownedRecipesAll.removeAll()
        ownedRecipesSome.removeAll()
        ownedRecipesNone.removeAll()
        
        let allRecipes = RecipeDict.shared.recipes
        let ownedIngs = OwnedIngredientsManager.shared.ownedIngredients
        let ownedDrinks = OwnedDrinksManager.shared.ownedDrinks
        
        for recipe in allRecipes {
            let recipeIngredients = recipe.ingredients
            let totalCount = recipeIngredients.count
            
            let ownedIngsCount = recipeIngredients.filter { ownedIngs.contains($0.code) }.count
            let ownedDrinksCount = recipeIngredients.filter { ingredient in
                ownedDrinks.contains(where: { $0.baseCode == ingredient.code })
            }.count
            
            let ownedCount = ownedIngsCount + ownedDrinksCount
            
            if ownedCount == totalCount {
                ownedRecipesAll.append(recipe.english_name)
            } else if ownedCount == 0 {
                ownedRecipesNone.append(recipe.english_name)
            } else {
                ownedRecipesSome.append(recipe.english_name)
            }
        }
        
//        print("fetchAvailableRecipes")
        
        
        save()
    }
    
    func isSectionEmpty(section: Int) -> Bool {
        switch section {
        case 0:
            return ownedRecipesAll.isEmpty
        case 1:
            return ownedRecipesSome.isEmpty
        case 2:
            return ownedRecipesNone.isEmpty
        default:
            return true
        }
    }
}
