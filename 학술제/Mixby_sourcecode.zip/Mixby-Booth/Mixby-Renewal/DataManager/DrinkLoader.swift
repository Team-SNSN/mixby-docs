//
//  DrinkLoader.swift
//  Mixby-Booth
//
//  Created by Anthony on 9/29/25.
//

import Foundation

struct Drink: Codable, Identifiable {
    var id: String { code }
    let code: String
    let name: String
    let baseCode: String
    let type: String
    let volume: String
    let alcohol: String
    let description: String
}

class DrinkLoader: ObservableObject {
    static let shared = DrinkLoader() // Singleton instance
    
    @Published var drink: Drink?

    private init() {} // Prevent external instantiation

    func fetchDrink(code: String, completion: @escaping (Bool, Drink?) -> Void) {
        let urlString = ServerURL.d_code_search + code
        guard let url = URL(string: urlString) else {
            print("❌ Invalid URL")
            completion(false, nil)
            return
        }

        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                print("❌ Network error: \(error)")
                completion(false, nil)
                return
            }

            guard let data = data else {
                print("❌ No data received")
                completion(false, nil)
                return
            }

            // Check for "success": false
            if let jsonObject = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: Any],
               let success = jsonObject["success"] as? Bool, success == false {
                let message = jsonObject["message"] as? String ?? "Unknown error"
                print("❌ Server error: \(message)")
                completion(false, nil)
                return
            }

            do {
                let decoder = JSONDecoder()
                let decodedDrink = try decoder.decode(Drink.self, from: data)
                DispatchQueue.main.async {
                    self.drink = decodedDrink
                    completion(true, decodedDrink)
                }
            } catch {
                print("❌ Decoding error: \(error)")
                completion(false, nil)
            }
        }.resume()
    }
}


@MainActor
final class OwnedDrinksManager: ObservableObject {
    static let shared = OwnedDrinksManager()
    
    @Published var ownedDrinks: [Drink] = [] {
        didSet { save() }
    }
    
    private init() {
        load()
    }
    
    private func load() {
        if let data = UserDefaults.standard.data(forKey: "OwnedDrinks"),
           let decoded = try? JSONDecoder().decode([Drink].self, from: data) {
            ownedDrinks = decoded
        } else {
            ownedDrinks = []
        }
    }

    private func save() {
        if let encoded = try? JSONEncoder().encode(ownedDrinks) {
            UserDefaults.standard.set(encoded, forKey: "OwnedDrinks")
        }
    }

    func addDrink(_ drink: Drink) {
        guard !ownedDrinks.contains(where: { $0.code == drink.code }) else { return }
        ownedDrinks.append(drink)
    }

    func removeDrink(_ drink: Drink) {
        ownedDrinks.removeAll { $0.code == drink.code }
    }

    func clearAll() {
        ownedDrinks.removeAll()
    }
}
