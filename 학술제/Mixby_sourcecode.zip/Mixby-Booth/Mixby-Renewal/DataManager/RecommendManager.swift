//
//  RecommendManager.swift
//  Mixby-Booth
//
//  Created by Anthony on 11/14/25.
//


import Foundation

struct RecommendItem: Codable, Equatable {
    let name: String
    let tag: String
    let reason: String
    var recipe: Recipe?

    static func == (lhs: RecommendItem, rhs: RecommendItem) -> Bool {
        return lhs.name == rhs.name &&
        lhs.tag == rhs.tag &&
        lhs.reason == rhs.reason &&
        lhs.recipe?.code == rhs.recipe?.code
    }
}

final class RecommendManager: ObservableObject {

    static let shared = RecommendManager()

    private init() {}

    @Published private(set) var savedRecommendations: [RecommendItem] = []

    private func storeRecommendations(_ items: [RecommendItem]) {
        let enriched = items.map { item -> RecommendItem in
            var mutableItem = item
            mutableItem.recipe = RecipeDict.shared.recipe(forEnglishName: item.name)
            return mutableItem
        }

        DispatchQueue.main.async {
            self.savedRecommendations = enriched
        }
    }
    
    func resetRecommendations() {
        DispatchQueue.main.async {
            self.savedRecommendations = []
        }
    }

    struct RecommendRequest: Codable {
        let persona: String
        let cocktail_list: [String]
        let season: String
        let time: String
        let weather: String
    }

    struct RecommendResponse: Codable {
        let recommendation: [RecommendItem]
    }

    private struct RootResponse: Codable {
        let success: Bool
        let message: String
        let data: ResponseData
    }

    private struct ResponseData: Codable {
        let recommendation: String
    }

    func requestRecommendation(persona: String, cocktails: [String], season: String, time: String, weather: String, completion: @escaping (RecommendResponse?) -> Void) {

        let url = URL(string: ServerURL.recommendDefault)!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let body = RecommendRequest(
            persona: persona,
            cocktail_list: cocktails,
            season: season,
            time: time,
            weather: weather
        )
        
        print(body)

        guard let encoded = try? JSONEncoder().encode(body) else {
            completion(nil)
            return
        }

        request.httpBody = encoded

        URLSession.shared.dataTask(with: request) { data, _, _ in
            guard let data else {
                completion(nil)
                return
            }

            do {
                let root = try JSONDecoder().decode(RootResponse.self, from: data)
                guard let innerData = root.data.recommendation.data(using: .utf8) else {
                    completion(nil)
                    return
                }
                let final = try JSONDecoder().decode(RecommendResponse.self, from: innerData)
                self.storeRecommendations(final.recommendation)
                completion(final)
            } catch {
                print("Recommend decode error:", error)
                completion(nil)
            }
        }.resume()
    }
}
