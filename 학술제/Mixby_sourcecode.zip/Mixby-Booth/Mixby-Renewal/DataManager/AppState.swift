//
//  ServerLoader.swift
//  Mixby-Booth
//
//  Created by Anthony on 9/24/25.
//

import SwiftUI
import Foundation

private let serverHealthURLString = ServerURL.health

class AppState: ObservableObject {
    enum ServerStatus {
        case unknown, healthy, unhealthy, loading, complete
    }
    
    @Published var serverStatus: ServerStatus = .loading
    
    init() {
        startServerCheck()
    }
    
    func retryServerCheck() {
        startServerCheck()
    }
    
    private func startServerCheck() {
        Task { @MainActor in
            self.serverStatus = .loading
        }
        
        Task.detached { [weak self] in
            await self?.checkServerHealthWithTimeout()
        }
    }
    
    private func checkServerHealthWithTimeout() async {
        await withTaskGroup(of: Void.self) { group in
            group.addTask { [weak self] in
                await self?.performHealthCheck()
            }
            
            group.addTask { [weak self] in
                try? await Task.sleep(nanoseconds: 3_000_000_000)
                await self?.markUnhealthyIfStillLoading()
            }
            
            _ = await group.next()
            group.cancelAll()
        }
    }
    
    private func markUnhealthyIfStillLoading() async {
        await MainActor.run {
            if self.serverStatus == .loading {
                self.serverStatus = .unhealthy
            }
        }
    }

    private func performHealthCheck() async {
        guard !serverHealthURLString.isEmpty,
              let url = URL(string: serverHealthURLString) else {
            await MainActor.run {
                self.serverStatus = .unhealthy
            }
            return
        }
        
        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            let response = try JSONDecoder().decode(HealthResponse.self, from: data)
            
            if response.data.status == "healthy" {
                await MainActor.run {
                    self.serverStatus = .healthy
                }
                Task.detached { [weak self] in
                    await self?.fetchData()
                }
            } else {
                await MainActor.run {
                    self.serverStatus = .unhealthy
                }
            }
        } catch {
            let nsError = error as NSError
            print("❌ Health check failed")
            print("Error Domain: \(nsError.domain)")
            print("Error Code: \(nsError.code)")
            print("Description: \(nsError.localizedDescription)")
            await MainActor.run {
                self.serverStatus = .unhealthy
            }
        }
    }

    func fetchData() async {
        RecipeDict.shared.fetchdict(from: ServerURL.allRecipes)
        IngredientDict.shared.fetchDict(from: ServerURL.allIngredients)
    }
    
    // MARK: - HealthResponse
    struct HealthResponse: Decodable {
        struct Data: Decodable {
            let status: String
        }
        let success: Bool
        let message: String
        let data: Data
    }
}
