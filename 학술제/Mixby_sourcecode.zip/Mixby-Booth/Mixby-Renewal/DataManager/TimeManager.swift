//
//  TimeManager.swift
//  Mixby-Booth
//
//  Created by Anthony on 11/14/25.
//



import Foundation

final class TimeManager {

    static let shared = TimeManager()

    private init() {}

    enum TimeCategory: String {
        case morning = "아침"
        case day = "낮"
        case evening = "저녁"
        case night = "밤"
    }

    func currentTimeCategory() -> TimeCategory {
        let hour = Calendar.current.component(.hour, from: Date())

        switch hour {
        case 6..<12:
            return .morning
        case 12..<18:
            return .day
        case 18..<22:
            return .evening
        default:
            return .night
        }
    }

    enum Weekday: String {
        case monday = "월요일"
        case tuesday = "화요일"
        case wednesday = "수요일"
        case thursday = "목요일"
        case friday = "금요일"
        case saturday = "토요일"
        case sunday = "일요일"
    }

    func currentWeekday() -> Weekday {
        let weekdayNumber = Calendar.current.component(.weekday, from: Date())
        switch weekdayNumber {
        case 1: return .sunday
        case 2: return .monday
        case 3: return .tuesday
        case 4: return .wednesday
        case 5: return .thursday
        case 6: return .friday
        case 7: return .saturday
        default: return .sunday
        }
    }

    enum Season: String {
        case spring = "봄"
        case summer = "여름"
        case autumn = "가을"
        case winter = "겨울"
    }

    func currentSeason() -> Season {
        let month = Calendar.current.component(.month, from: Date())

        switch month {
        case 3...5:
            return .spring
        case 6...8:
            return .summer
        case 9...11:
            return .autumn
        default:
            return .winter
        }
    }
}
