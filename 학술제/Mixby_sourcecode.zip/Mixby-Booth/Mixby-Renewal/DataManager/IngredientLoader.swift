//
//  Ingredient.swift
//  Mixby-Renewal
//
//  Created by Anthony on 11/9/25.
//

import Foundation

struct Ingredient: Codable {
    let name: String
    let code: String
    let amount: String?
    let unit: String?
}

struct IngredientResponse: Codable {
    let success: Bool
    let message: String
    let data: IngredientData
}

struct IngredientData: Codable {
    let ingredients: [Ingredient]
}

final class IngredientDict: ObservableObject {
    static let shared = IngredientDict()
    private init() {}

    @Published private(set) var ingredients: [Ingredient] = []

    func fetchDict(from urlString: String, completion: ((Bool) -> Void)? = nil) {
        guard let url = URL(string: urlString) else {
            print("❌ 잘못된 URL: \(urlString)")
            completion?(false)
            return
        }

        URLSession.shared.dataTask(with: url) { data, _, error in
            if let error = error {
                print("❌ 네트워크 에러: \(error.localizedDescription)")
                completion?(false)
                return
            }

            guard let data = data else {
                print("⚠️ 데이터가 비어있습니다.")
                completion?(false)
                return
            }

            do {
                let decoded = try JSONDecoder().decode(IngredientResponse.self, from: data)
                DispatchQueue.main.async {
                    self.ingredients = decoded.data.ingredients
                    completion?(true)
                }
            } catch {
                print("IngredientDict: JSON 디코딩 실패: \(error.localizedDescription)")
                completion?(false)
            }
        }.resume()
    }

    func ingredient(forCode code: String) -> Ingredient? {
        return ingredients.first { $0.code == code }
    }
}

@MainActor
final class OwnedIngredientsManager: ObservableObject {
    static let shared = OwnedIngredientsManager()

    @Published var ownedIngredients: [String] = []

    private let userDefaultsKey = "OwnedIngredients"

    private init() {
        load()
    }

    func addIngredient(_ ingredient: String) {
        if !ownedIngredients.contains(ingredient) {
            ownedIngredients.append(ingredient)
            save()
        }
    }

    func removeIngredient(_ ingredient: String) {
        if let index = ownedIngredients.firstIndex(of: ingredient) {
            ownedIngredients.remove(at: index)
            save()
        }
    }

    func load() {
        if let savedIngredients = UserDefaults.standard.array(forKey: userDefaultsKey) as? [String] {
            ownedIngredients = savedIngredients
        }
    }

    func save() {
        UserDefaults.standard.set(ownedIngredients, forKey: userDefaultsKey)
    }

    func clearAll() {
        ownedIngredients.removeAll()
        UserDefaults.standard.removeObject(forKey: userDefaultsKey)
    }
}
